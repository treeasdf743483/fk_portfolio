#pragma once
#include "BASE.h"
#include "WINDOW.h"
#include "DIRECT3D10.h"
#include "CAMERA.h"
#include "MESH.h"
#include "SKINMESH.h"
#include "CHARACTER.h"
#include "SOUND.h"

#define GRAV 9.8f/60.0f
#define MAX_SHOT 200
#define MAX_MONSTER 5
#define BAKA_TIME 400 //�����X�^�[���l�����ɕ����C������܂ł̃V���L���O�^�C���@�傫���قǔn��
#define HITO_SPEED 0.1
#define MONSTER_SPEED 0.13
#define SHOT_WAIT 20 //�e�̘A�ˊԊu�@�Ⴂ�قǊԊu���Z��

//
//
enum SCENE
{
	OPENING,
	PLAY_STAGE1,
	PLAY_STAGE2,
	PLAY_STAGE3,
	WIN,
	GAMEOVER,
};
//
//
struct SHOT_DATA
{
	D3DXVECTOR3 vPos;
	D3DXVECTOR3 vDir;
};

//
//
class DIRECTOR : public CELEMENT
{
public:
	//Data
	HINSTANCE m_hInstance;
	WINDOW* m_pWindow;
	HWND m_hWnd;
	SCENE m_Scene;
	DIRECT3D10* m_pD3d;
	CAMERA* m_pCamera;
	MESH* m_pFieldMesh;
	MESH* m_pShotMesh;
	int m_iNumShot;
	SHOT_DATA m_Shot[MAX_SHOT];
	SHOT_DATA m_Shot30[MAX_SHOT];
	SHOT_DATA m_Shot31[MAX_SHOT];
	SHOT_DATA m_Shot32[MAX_SHOT];
	SHOT_DATA m_Shot33[MAX_SHOT];

	SHOT_DATA m_Shot40[MAX_SHOT];
	SHOT_DATA m_Shot41[MAX_SHOT];
	SHOT_DATA m_Shot42[MAX_SHOT];

	CHARACTER* m_pHito;
	int m_iNumMonster;
	CHARACTER* m_pMonster[MAX_MONSTER];
	SOUND* m_pSound;
	int m_iBGMSound;
	int m_iHitSound;
	int m_iFireSound[5];
	int m_iGameOverSound;
	int m_iFireSoundCounter;
	//Method
	DIRECTOR();
	~DIRECTOR();
	HRESULT Init();
	void Run(HINSTANCE);
	void MainLoop();
	void Stage1();
	void GameOver();
	void Win();
	void FixFPS60();
	void Reset();
};