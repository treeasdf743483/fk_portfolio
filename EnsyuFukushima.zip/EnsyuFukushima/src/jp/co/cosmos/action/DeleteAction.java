package jp.co.cosmos.action;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.cosmos.bean.DeleteBean;
import jp.co.cosmos.bean.LoginBean;
import jp.co.cosmos.bean.UpdateBean;
import jp.co.cosmos.common.ErrorConst;
import jp.co.cosmos.common.ResourseKeyConst;
import jp.co.cosmos.common.SettingConst;
import jp.co.cosmos.dao.DeleteDao;
import jp.co.cosmos.dao.ExistEmpNoDao;
import jp.co.cosmos.dao.ExistEmpNoDelFlgDao;
import jp.co.cosmos.dao.UpdateDao;
import jp.co.cosmos.form.DeleteForm;
import jp.co.cosmos.form.UpdateForm;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

public class DeleteAction extends Action{

	// ���O���`
	static Log logger = LogFactory.getLog(LoginAction.class);

	/**
	 * �]�ƈ����̓o�^
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

	// ��`
	DeleteForm deleteForm = (DeleteForm) form;
	DeleteDao deleteDao = new DeleteDao();
	ActionMessages messages = new ActionMessages();

	LoginBean loginBean = new LoginBean();
	DeleteBean deleteBean = new DeleteBean();
	logger.info(SettingConst.LOG_START);

	try {
		// Bean�̒��g���R�s�[
		BeanUtils.copyProperties(deleteBean,deleteForm);
		HttpSession session = ((HttpServletRequest) request).getSession();
		loginBean = (LoginBean) session
		.getAttribute(SettingConst.LOGIN_BEAN_KEY);
		Integer.parseInt("a");

		// �C���`�F�b�N
		if (deleteDao.isDelete(deleteBean)) {
			logger.info(SettingConst.MESSEGE_SUCCESS);
			logger.info(SettingConst.LOG_END);
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(
					ResourseKeyConst.DELETE_SUCCESS));
			saveMessages(request, messages);


			return mapping.findForward(SettingConst.ENLIST_SUCCESS);
		} else {
			messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(
					ResourseKeyConst.DELETE_FAILURE));
			saveMessages(request, messages);

			logger.info(SettingConst.MESSEGE_FAILURE);
			logger.info(SettingConst.LOG_END);
			return mapping.findForward(SettingConst.ENLIST_FAILURE);
		}

	} catch (SQLException e) {
		logger.error(ErrorConst.ERRORS_SQL, e);
		logger.error(ErrorConst.ERRORS_SQL, e);
		//�G���[���b�Z�[�W�̕�����ϊ�
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		pw.flush();
		String str = sw.toString();
		request.setAttribute("systemError",e);
		request.setAttribute(SettingConst.SYSTEM_ERROR, e);
		request.setAttribute("errorDetail",str);
		return mapping.findForward(SettingConst.ERROR_KEY);
	} catch (Exception e) {
		logger.fatal(ErrorConst.ERRORS_FATAL, e);
		logger.error(ErrorConst.ERRORS_SQL, e);

		request.setAttribute("systemError",e);
		request.setAttribute("errorDetail",e.getStackTrace());
		request.setAttribute(SettingConst.ERROR_KEY, e);
		return mapping.findForward(SettingConst.ERROR_KEY);
	} finally {
		logger.info(SettingConst.LOG_END);
	}
}

}
