package jp.co.cosmos.util;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
/**
 *
 * @author �����\�C
 * �쐬�� 2014/5/20
 *
 */
public class SafePassword {
	private static int STRETCH_COUNT = 10000;
	private static final String SALT = "cosmos";


	/**
	 * salt + �X�g���b�`���O�����p�X���[�h���擾(����)
	 *
	 * @param password
	 * @param userId
	 * @return
	 */
	public static String getStretchedPassword(String code) {
		String hash = getSha256(code);

		for (int i = 0; i < STRETCH_COUNT; i++) {
			hash = getSha256(hash);
		}

		return hash;
	}

	/**
	 * �����񂩂� SHA256 �̃n�b�V���l���擾
	 *
	 * @param target
	 * @return
	 */
	private static String getSha256(String target) {
		MessageDigest md = null;
		StringBuffer buf = new StringBuffer();
		try {
			md = MessageDigest.getInstance("SHA-256");
			md.update(target.getBytes());
			byte[] digest = md.digest();

			for (int i = 0; i < digest.length; i++) {
				buf.append(String.format("%02x", digest[i]));
			}

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		return buf.toString();
	}

}
