package jp.co.cosmos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.cosmos.bean.DutyListBean;
import jp.co.cosmos.bean.ExamListBean;
import jp.co.cosmos.bean.SearchBean;
import jp.co.cosmos.common.ErrorConst;
import jp.co.cosmos.common.SettingConst;
import jp.co.cosmos.util.SafePassword;
import jp.co.cosmos.util.DBUtil;
import jp.co.cosmos.util.ValidateUtil;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class SearchDao extends DBUtil {
	static Log logger = LogFactory.getLog(SearchDao.class);

	public SearchDao() {
		logger.info(SettingConst.LOG_NEW);
	}



	/**
	 * �]�ƈ����擾
	 *
	 * @param userId
	 * @return SearchBean
	 */
	public SearchBean selectEmpInfo(String userId) throws SQLException,
			Exception {
		logger.info(SettingConst.LOG_START);

		// id���]�ƈ��ԍ��ɕ�����
		String employeeNo = userId.substring(SettingConst.EMP_NO_BIGIN,
				SettingConst.EMP_NO_END);
		System.out.println(employeeNo);
	    int count = 0;
		// ��`
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();
		SearchBean searchBean = new SearchBean();
		String gender = "";

		try {
			conn = this.connectionDB();
			// SQL���̐���
			sqlBuffer.append("select ");
			sqlBuffer.append("emp_basic_info.emp_no ");
			sqlBuffer.append(",first_name_kanji ");
			sqlBuffer.append(",last_name_kanji ");
			sqlBuffer.append(",last_name_kana ");
			sqlBuffer.append(",first_name_kana ");
			sqlBuffer.append(",birth ");
			sqlBuffer.append(",gender ");
			sqlBuffer.append(",family_register ");
			sqlBuffer.append(",join_date ");
			sqlBuffer.append(",post_cd ");
			sqlBuffer.append(",address_pref ");
			sqlBuffer.append(",address_munic ");
			sqlBuffer.append(",address_addr ");
			sqlBuffer.append(",address_apart ");
			sqlBuffer.append(",tel_no ");
			sqlBuffer.append(",nearest_station ");
			sqlBuffer.append(",duty_nm ");
			sqlBuffer.append(",login.del_flg ");
			sqlBuffer.append("from ");
			sqlBuffer.append("emp_address_info ");
			sqlBuffer.append(",emp_duty_info ");
			sqlBuffer.append(",emp_basic_info ");
			sqlBuffer.append(",duty ");
			sqlBuffer.append(",login ");
			sqlBuffer.append("where ");
			sqlBuffer.append("emp_basic_info.emp_no=emp_address_info.emp_no ");
			sqlBuffer.append(" and emp_basic_info.emp_no=? ");
			sqlBuffer.append(" and emp_address_info.emp_no=? ");
			sqlBuffer.append(" and emp_duty_info.emp_no=? ");
			sqlBuffer.append(" and emp_duty_info.duty_cd=duty.duty_cd ");
			sqlBuffer.append(" and emp_basic_info.emp_no=emp_duty_info.emp_no ");
			sqlBuffer.append(" and emp_basic_info.emp_no=login.user_id ");
			sqlBuffer.append(" and emp_basic_info.del_flg='0' ");
			sqlBuffer.append(" and login.del_flg='0' ");
			sqlBuffer.append(" and emp_duty_info.del_flg='0' ");
			sqlBuffer.append(" and emp_address_info.del_flg='0' ");

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}
			ps = conn.prepareStatement(sqlBuffer.toString());

			// �l���Z�b�g
			ps.setString(1, employeeNo);
			ps.setString(2, employeeNo);
			ps.setString(3, employeeNo);

			// SQL���s
			rs = ps.executeQuery();

			if (logger.isDebugEnabled()) {
				logger.debug("SQL���s����");
			}

			while (rs.next()) {
				searchBean.setEmpNo(rs.getString("emp_basic_info.emp_no"));
				searchBean.setFirstNameKanji(rs.getString("first_name_kanji"));
				searchBean.setLastNameKanji(rs.getString("last_name_kanji"));
				searchBean.setFirstNameKana(rs.getString("first_name_kana"));
				searchBean.setLastNameKana(rs.getString("last_name_kana"));

				searchBean.setGender(rs.getString("gender"));
				searchBean.setBirthYear(ValidateUtil.changeToWareki(rs.getString("birth").substring(0,4)));
				searchBean.setBirthEra(ValidateUtil.calEra(rs.getString("birth").substring(0,4)));
				searchBean.setBirthMonth((rs.getString("birth").substring(5,7)));
				searchBean.setBirthDay(rs.getString("birth").substring(8,10));
				searchBean.setJoinYear(ValidateUtil.changeToWareki(rs.getString("join_date").substring(0,4)));
				searchBean.setJoinEra(ValidateUtil.calEra(rs.getString("join_date").substring(0,4)));
				searchBean.setJoinMonth((rs.getString("join_date").substring(5,7)));
				searchBean.setJoinDay(rs.getString("join_date").substring(8,10));
				searchBean.setBirth(ValidateUtil.changeToEraFromDate(rs
						.getString("birth").substring(0, 4))
						+ "."
						+ rs.getString("birth").substring(5, 7)
						+ "."
						+ rs.getString("birth").substring(8, 10));
				searchBean.setJoinDate(ValidateUtil.changeToEraFromDate(rs
						.getString("join_date").substring(0, 4))
						+ "."
						+ rs.getString("join_date").substring(5, 7)
						+ "."
						+ rs.getString("join_date").substring(8, 10));
				searchBean.setDuty(rs.getString("duty_nm"));
				searchBean.setFamilyRegister(rs.getString("family_register"));
				searchBean.setPostCd(rs.getString("post_cd"));
				searchBean.setPostCd1(rs.getString("post_cd").substring(0,3));
				searchBean.setPostCd2(rs.getString("post_cd").substring(4,8));
				searchBean.setAddressPref(rs.getString("address_pref"));
				searchBean.setAddressMunic(rs.getString("address_munic"));
				searchBean.setAddressAddr(rs.getString("address_addr"));
				searchBean.setAddressApart(rs.getString("address_apart"));
				searchBean.setTelNo(rs.getString("tel_no"));
				System.out.println(ValidateUtil.hyphenIndex(rs.getString("tel_no"),1));
				searchBean.setTelNo1(rs.getString("tel_no").substring(0,3));
				searchBean.setTelNo2(rs.getString("tel_no").substring(4,8));
				searchBean.setTelNo3(rs.getString("tel_no").substring(9));
				searchBean.setStation(rs.getString("nearest_station"));

			count++;
			}

			searchBean.setCount(count);
			System.out.println("�J�E���g" + count);
		} catch (SQLException e) {

			throw e;
		} catch (Exception e) {

			throw e;
		} finally {

			// DB�ؒf
			this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);

		}

		return searchBean;

	}

	/**
	 * ���Ǝ������擾
	 *
	 * @param userId
	 * @return SearchBean
	 */
	public List<ExamListBean> selectExam() throws SQLException,
			Exception {
		logger.info(SettingConst.LOG_START);

		// ��`
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();
		List<ExamListBean> examList = new ArrayList<ExamListBean>();

		try {
			conn = this.connectionDB();
			// SQL���̐���
			sqlBuffer.append("select ");
			sqlBuffer.append("examination_nm ");
			sqlBuffer.append(",examination_cd ");
			sqlBuffer.append("from ");
			sqlBuffer.append("examination ");
			sqlBuffer.append("order by ");
			sqlBuffer.append("sort_key asc ");


			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}
			ps = conn.prepareStatement(sqlBuffer.toString());

				// SQL���s
			rs = ps.executeQuery();

			if (logger.isDebugEnabled()) {
				logger.debug("SQL���s����");
			}

			while (rs.next()) {
				ExamListBean examBean = new ExamListBean();
				examBean.setExaminationNm(rs.getString("examination_nm"));
				examBean.setExaminationCd(rs.getString("examination_cd"));

				examList.add(examBean);

			}

		} catch (SQLException e) {

			throw e;
		} catch (Exception e) {

			throw e;
		} finally {

			// DB�ؒf
			this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);
		}

		return examList;

	}

	/**
	 * ���Ǝ������擾(�]�ƈ��ԍ�����)
	 *
	 * @param userId
	 * @return SearchBean
	 */
	public  String[][] selectExamEmpNo(String empNo) throws SQLException,
			Exception {
		logger.info(SettingConst.LOG_START);
		// ��`
		List<String> examNmList = new ArrayList<String>();
		List<String> examCdList = new ArrayList<String>();
		String[] examinationCdArray = new String[9];
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();
		List<ExamListBean> examList = new ArrayList<ExamListBean>();
		String empNo2 = empNo.substring(SettingConst.EMP_NO_BIGIN,
				SettingConst.EMP_NO_END);


		try {
			conn = this.connectionDB();
			// SQL���̐���
			sqlBuffer.append("select ");
			sqlBuffer.append("examination_nm ");
			sqlBuffer.append(",emp_examination_info.examination_cd ");
			sqlBuffer.append("from ");
			sqlBuffer.append("examination ");
			sqlBuffer.append(",emp_examination_info ");
			sqlBuffer.append("where emp_examination_info.examination_cd=examination.examination_cd ");
			sqlBuffer.append("and emp_examination_info.emp_no=? ");

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}
			ps = conn.prepareStatement(sqlBuffer.toString());

			ps.setString(1, empNo2);

				// SQL���s
			rs = ps.executeQuery();

			if (logger.isDebugEnabled()) {
				logger.debug("SQL���s����");
			}

			int i = 0;
			while (rs.next()) {
				examNmList.add(rs.getString("examination_nm"));
				examCdList.add(rs.getString("examination_cd"));
				System.out.println("����" + rs.getString("examination_nm"));

				//examList.add(searchBean);

			}

			String[] examNmArr =new String [examNmList.size()];
			String[] examCdArr =new String [examCdList.size()];

			for(i=0 ;i < examNmList.size();i++){
				examNmArr[i] = examNmList.get(i);
				examCdArr[i] = examCdList.get(i);
				System.out.println("5552" + examNmList.get(i));
			}
//			SearchBean searchBean = new SearchBean();
//			searchBean.setExaminationNm(array[]);

			return new String[][]{examNmArr,examCdArr};
		} catch (SQLException e) {

			throw e;
		} catch (Exception e) {

			throw e;
		} finally {

			// DB�ؒf
			this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);
		}

	}


	/**
	 * ���͂��ꂽ��3������]�ƈ��E�����i���擾
	 *
	 * @param userId
	 * @return
	 */
	public String selectDutyCd(String userId) throws SQLException, Exception {

		// ��`
		logger.info(SettingConst.LOG_START);
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();
		String empNo = userId.substring(1, 4);
		String dutyCd = "";
		try {
			conn = this.connectionDB();
			// SQL���̐���
			sqlBuffer.append("select ");
			sqlBuffer.append("emp_duty_info.duty_cd ");
			sqlBuffer.append(",duty_nm ");
			sqlBuffer.append("from ");
			sqlBuffer.append("emp_duty_info ");
			sqlBuffer.append(",duty ");
			sqlBuffer.append("where ");
			sqlBuffer.append("emp_duty_info.emp_no=? ");
			sqlBuffer.append("and emp_duty_info.duty_cd=duty.duty_cd ");

			// �v���y�A�[�h�X�e�[�g�����g�̍쐬
			ps = conn.prepareStatement(sqlBuffer.toString());

			// �l���Z�b�g
			ps.setString(1, empNo);

			// SQL���s
			rs = ps.executeQuery();

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			while (rs.next()) {
				SearchBean searchBean = new SearchBean();
				dutyCd=rs.getString("duty_cd");
				 searchBean.setDutyCd(rs.getString("duty_cd"));
				 searchBean.setDutyNm(rs.getString("duty_nm"));
			}
			return dutyCd;
		} catch (SQLException e) {
			logger.error(ErrorConst.ERRORS_SQL);
			throw e;
		} catch (Exception e) {
			logger.error(ErrorConst.ERRORS_FATAL);
			throw e;
		} finally {
			// DB�ؒf
			this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);
		}

	}

	/**
	 *DB����E�����i��������Ă���
	 *
	 * @param userId
	 * @return
	 **/
	public List<DutyListBean> selectDutyNm() throws SQLException, Exception {
		logger.info(SettingConst.LOG_START);
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();

		List<DutyListBean> arrayList = new ArrayList<DutyListBean>();
		try {
			conn = this.connectionDB();
			// SQL���̐���
			sqlBuffer.append("select ");
			sqlBuffer.append("duty_nm ");
			sqlBuffer.append(",duty_cd ");
			sqlBuffer.append("from ");
			sqlBuffer.append("duty ");
			sqlBuffer.append("order by ");
			sqlBuffer.append("duty_cd asc ");

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			ps = conn.prepareStatement(sqlBuffer.toString());

			// SQL���s
			rs = ps.executeQuery();

			if (logger.isDebugEnabled()) {
				logger.debug("SQL���s����");
			}
			// ���X�ƒl���擾
			while (rs.next()) {
				DutyListBean menuBean = new DutyListBean();
				menuBean.setDutyNm(rs.getString("duty_nm"));
				menuBean.setDutyCd(rs.getString("duty_cd"));
				arrayList.add(menuBean);
			}
			return arrayList;
		} catch (SQLException e) {

			logger.error(ErrorConst.ERRORS_SQL, e);
			throw e;
		} catch (Exception e) {

			logger.fatal(ErrorConst.ERRORS_FATAL, e);
			throw e;
		} finally {
			// DB�ؒf
			this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);

		}

	}

	/**
	 * �E�����i����v���邩�ǂ����m���߂�
	 * @param userId
	 * @return
	 * @throws SQLException
	 * @throws Exception
	 */
	public boolean isDutyCd(String userId) throws SQLException, Exception {

		// ��`
		boolean flg = false;
		String dutyCd = selectDutyCd(userId);
		String dutyCdInput = userId.substring(0,1);

		if(dutyCd.equals(dutyCdInput)){
			flg = true;
		}
		return flg;
	}
}
