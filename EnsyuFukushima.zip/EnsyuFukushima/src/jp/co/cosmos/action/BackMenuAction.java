package jp.co.cosmos.action;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.cosmos.bean.LoginBean;
import jp.co.cosmos.dao.LoginDao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class BackMenuAction extends Action{

	static Log logger = LogFactory.getLog(LoginDao.class);

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {



		try{
		//�Z�b�V�������擾
		HttpSession session = ((HttpServletRequest) request).getSession();
		//LoginBean loginBean = (LoginBean) session.getAttribute("loginBean");
		//�Z�b�V������j��
		session.removeAttribute("key");
		// ���O�C����ʂ֖߂�
		return mapping.findForward("success");

		} catch (Exception e) {

			logger.fatal("�v���I�ȃG���[", e);
			request.setAttribute("systemError", e);
			request.setAttribute("errorDetail",e.getStackTrace());

			return mapping.findForward("error");
		}

	}
}
