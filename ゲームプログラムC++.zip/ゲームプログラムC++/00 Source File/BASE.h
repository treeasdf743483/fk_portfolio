#pragma once
#include <stdio.h>
#include <windows.h>
#include <d3d10.h>
#include <d3dx10.h>
//�K�v�ȃ��C�u�����t�@�C���̃��[�h
#pragma comment(lib,"d3d10.lib")
#pragma comment(lib,"d3dx10.lib")
#pragma comment(lib,"winmm.lib")

//
#pragma warning(disable : 4305)
#pragma warning(disable : 4996)
#pragma warning(disable : 4018)
#pragma warning(disable : 4101)
//
//

#define APP_NAME L"game example 3D action"
#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600

//
//
#define SAFE_DELETE(p) { if(p) { delete (p); (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p); (p)=NULL; } }
#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }
#define MFAIL(code,string) if(FAILED( code ) ) { MessageBox(0,string,L"error",MB_OK); return E_FAIL; }
#define MFALSE(code,string) if(!( code ) ) { MessageBox(0,string,L"error",MB_OK); return E_FAIL; }
#define MSG(t) MessageBox(0,t,0,MB_OK);

//
//
class CELEMENT
{
};

//
//�v���g�^�C�v
void InitDirectory(WCHAR* root);
void SetRootDirectory();
void SetDataDirectory();
void SetVisualDirectory();
void SetShaderDirectory();
void SetSoundDirectory();