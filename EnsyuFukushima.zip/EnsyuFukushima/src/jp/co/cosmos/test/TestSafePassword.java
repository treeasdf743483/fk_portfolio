package jp.co.cosmos.test;


import static org.junit.Assert.*;
import jp.co.cosmos.util.SafePassword;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestSafePassword {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}
	@Test
	public void getStretchedPassword_�n�b�V����(){
		assertEquals("9d65f5c0863129182c0893b0feadca84680ad5989c5bf66305fac69b92c31307",SafePassword.getStretchedPassword("006cosmoscosmos"));
	}
}
