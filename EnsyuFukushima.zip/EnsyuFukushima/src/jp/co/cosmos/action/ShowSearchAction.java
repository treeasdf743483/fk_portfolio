package jp.co.cosmos.action;

import java.io.PrintWriter;
import java.io.StringWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.cosmos.common.SettingConst;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class ShowSearchAction extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		try{
		HttpSession session = request.getSession();
		session.setAttribute("key",request.getParameter("key"));
		return mapping.findForward(SettingConst.ENLIST_SUCCESS);
		}catch(Exception e){
			request.setAttribute("systemError",e);
			request.setAttribute("errorDetail",e.getStackTrace());
			return mapping.findForward("error");
		}
	}
}
