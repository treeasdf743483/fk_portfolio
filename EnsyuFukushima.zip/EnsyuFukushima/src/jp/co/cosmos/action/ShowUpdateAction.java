package jp.co.cosmos.action;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import jp.co.cosmos.bean.DutyListBean;
import jp.co.cosmos.bean.ExamListBean;
import jp.co.cosmos.bean.ShowUpdateBean;
import jp.co.cosmos.common.ErrorConst;
import jp.co.cosmos.common.SettingConst;
import jp.co.cosmos.dao.ShowInsertDao;
import jp.co.cosmos.dao.ShowUpdateDao;
import jp.co.cosmos.form.LoginForm;
import jp.co.cosmos.form.ShowUpdateForm;
import jp.co.cosmos.util.ListUtil;

public class ShowUpdateAction extends Action{

	static Log logger = LogFactory.getLog(LoginAction.class);

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

	logger.info(SettingConst.LOG_START);
	// ��`
	ShowUpdateBean showUpdateBean = new ShowUpdateBean();
	List<DutyListBean> dutyNmList = new ArrayList<DutyListBean>();
	ShowUpdateForm showUpdateForm = (ShowUpdateForm) form;

	try {
		// select���ď����擾�B
		ShowUpdateDao showUpdateDao = new ShowUpdateDao();
		showUpdateBean  = showUpdateDao.selectEmpNo(showUpdateForm.getEmpNo());

		// jsp���ɃZ�b�g����
		request.setAttribute("examinationNmList", showUpdateBean);
		request.setAttribute("dutyNmList", dutyNmList);
		request.setAttribute("todoufukenList", ListUtil.getTodoufukenList());
		request.setAttribute("eraList", ListUtil.getEraList());
		request.setAttribute("showUpdateBean", showUpdateBean);
		request.setAttribute("initDuty",showUpdateBean.getDutyNm());
		if(showUpdateBean.getGender().equals("1")){
			PropertyUtils.setProperty(form, "rdo_name", "1");
		}
		else if(showUpdateBean.getGender().equals("2")){
			PropertyUtils.setProperty(form, "rdo_name", "2");
		}
		// �J��
		return mapping.findForward("success");
		// �J��
	} catch (SQLException e) {
		logger.error(ErrorConst.ERRORS_SQL, e);

		request.setAttribute("systemError", e);
		request.setAttribute("errorDetail",e.getStackTrace());
		return mapping.findForward("error");
	} catch (Exception e) {
		logger.fatal(ErrorConst.ERRORS_FATAL, e);
		request.setAttribute("systemError", e);
		request.setAttribute("errorDetail",e.getStackTrace());
		return mapping.findForward("error");
	} finally {
		logger.info(SettingConst.LOG_END);
	}
	}
}
