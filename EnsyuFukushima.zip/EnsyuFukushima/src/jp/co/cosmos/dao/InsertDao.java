package jp.co.cosmos.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.cosmos.bean.InsertBean;

import jp.co.cosmos.common.ErrorConst;
import jp.co.cosmos.common.SettingConst;

import jp.co.cosmos.util.DBUtil;
import jp.co.cosmos.util.SafePassword;
import jp.co.cosmos.util.ValidateUtil;
/**
 * �쐬�� 2014/05/29
 *
 * @author �����\�C
 *
 */
public class InsertDao extends DBUtil {

	// ���O�̒�`
	static Log logger = LogFactory.getLog(InsertDao.class);

	private Connection conn = null;
	public InsertDao() {
		logger.info(SettingConst.LOG_NEW);
	}

	/**
	 * �o�^�����`�F�b�N
	 *
	 * @param insertBean
	 * @param name
	 * @return true:�o�^���� false:�o�^���s
	 * @throws SQLException
	 * @throws Exception
	 */
	public boolean isEnroll(InsertBean insertBean, String name)
			throws SQLException, Exception {

		logger.info(SettingConst.LOG_START);
		try {
			conn = this.connectionDB();
			// �I�[�g�R�~�b�g�����Ȃ�
			conn.setAutoCommit(false);
			// �S�e�[�u���œo�^�m�F�`�F�b�N
			if (isInsertLogin(insertBean, name)
					&& isInsertBasicInfo(insertBean, name)
					&& isInsertAddressInfo(insertBean, name)
					&& isInsertDutyInfo(insertBean, name)
					&& isInsertExamination(insertBean, name)) {
				conn.commit();
				return true;
			} else {
				conn.rollback();
				return false;

			}
		} catch (SQLException e) {
			logger.error(ErrorConst.ERRORS_SQL);
			throw e;
		} catch (Exception e) {
			logger.error(ErrorConst.ERRORS_FATAL);
			throw e;
		} finally {

			// DB�ؒf
			this.close(conn);
			logger.info(SettingConst.LOG_END);
		}
	}

	/**
	 * ���O�C���e�[�u���œo�^���s��
	 *
	 * @param insertBean
	 * @param name
	 * @return true:�o�^���� false:�o�^���s
	 * @throws SQLException
	 * @throws Exception
	 */
	private boolean isInsertLogin(InsertBean insertBean, String name)
			throws SQLException, Exception {
		logger.info(SettingConst.LOG_START);
		// ��`
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();
		boolean flg = false;
		String authFlg;

		// �p�X���[�h�̃n�b�V����
		String password = SafePassword.getStretchedPassword(insertBean
				.getEmpNo()
				+ "cosmos" + "cosmos");
		// �����t���O
		if (Integer.parseInt(insertBean.getDuty()) >= 4 && Integer.parseInt(insertBean.getDuty()) != 9) {
			authFlg = "1";
		} else {
			authFlg = "0";
		}

		try {

			// SQL���̐���
			sqlBuffer.append("insert ");
			sqlBuffer.append("into login ");
			sqlBuffer.append("values ");
			sqlBuffer.append("(?");
			sqlBuffer.append(",?");
			sqlBuffer.append(",?");
			sqlBuffer.append(",default");
			sqlBuffer.append(",?");
			sqlBuffer.append(",default)");

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			// �v���y�A�[�h�X�e�[�g�����g�̍쐬
			ps = conn.prepareStatement(sqlBuffer.toString());

			// �l���Z�b�g
			ps.setString(1, insertBean.getEmpNo());
			ps.setString(2, password);
			ps.setString(3, authFlg);
			ps.setString(4, name);

			// SQL���s
			int up = ps.executeUpdate();

			if (logger.isDebugEnabled()) {
				logger.debug("login�\insert���s����");
			}
			// �ꌏ�ł��擾�ł����true
			if (up > 0) {
				flg = true;
			} else {
				flg = false;
			}
			return flg;
		} catch (SQLException e) {
			logger.error(ErrorConst.ERRORS_SQL);
			throw e;
		} catch (Exception e) {
			logger.error(ErrorConst.ERRORS_FATAL);
			throw e;
		} finally {
			//
			// // DB�ؒf
			// this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);
		}

	}

	/**
	 * �]�ƈ���{���e�[�u���œo�^���s��
	 *
	 * @param insertBean
	 * @param name
	 * @return true:�o�^���� false:�o�^���s
	 * @throws SQLException
	 * @throws Exception
	 */
	private boolean isInsertBasicInfo(InsertBean insertBean, String name)
			throws SQLException, Exception {
		logger.info(SettingConst.LOG_START);
		// ��`
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();
		boolean flg = false;

		try {
			// SQL���̐���
			sqlBuffer.append("insert ");
			sqlBuffer.append("into emp_basic_info ");
			sqlBuffer.append("values ");
			sqlBuffer.append("(?,");
			sqlBuffer.append("?,");
			sqlBuffer.append("?,");
			sqlBuffer.append("?,");
			sqlBuffer.append("?,");
			sqlBuffer.append("?,");
			sqlBuffer.append("?,");
			sqlBuffer.append("?,");
			sqlBuffer.append("?,");
			sqlBuffer.append("default,");
			sqlBuffer.append("?,");
			sqlBuffer.append("default)");

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			// �v���y�A�[�h�X�e�[�g�����g�̍쐬
			ps = conn.prepareStatement(sqlBuffer.toString());

			// �l���Z�b�g
			ps.setString(1, insertBean.getEmpNo());
			ps.setString(2, insertBean.getLastNameKanji());
			ps.setString(3, insertBean.getFirstNameKanji());
			ps.setString(4, insertBean.getLastNameKana());
			ps.setString(5, insertBean.getFirstNameKana());
			ps.setString(6, ValidateUtil.changeToDateFromEra(insertBean
					.getBirthEra(), insertBean.getBirthYear(), insertBean
					.getBirthMonth(), insertBean.getBirthDay()));
			ps.setString(7, insertBean.getGender());
			ps.setString(8, insertBean.getFamilyRegister());
			ps.setString(9, ValidateUtil.changeToDateFromEra(insertBean
					.getJoinEra(), insertBean.getJoinYear(), insertBean
					.getJoinMonth(), insertBean.getJoinDay()));
			ps.setString(10, name);

			// SQL���s
			int up = ps.executeUpdate();

			if (logger.isDebugEnabled()) {
				logger.debug("��{���\insert���s����");
			}
			// �ꌏ�ł��擾�ł����true
			if (up > 0) {
				flg = true;
			} else {
				flg = false;
			}
			return flg;
		} catch (SQLException e) {
			logger.error(ErrorConst.ERRORS_SQL);
			throw e;
		} catch (Exception e) {
			logger.error(ErrorConst.ERRORS_FATAL);
			throw e;
		} finally {

			// // DB�ؒf
			// this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);
		}

	}

	/**
	 * �]�ƈ��Z�����e�[�u���œo�^���s��
	 *
	 * @param insertBean
	 * @param name
	 * @return true:�o�^���� false:�o�^���s
	 * @throws SQLException
	 * @throws Exception
	 */
	private boolean isInsertAddressInfo(InsertBean insertBean, String name)
			throws SQLException, Exception {
		logger.info(SettingConst.LOG_START);
		// ��`
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();
		boolean flg = false;

		try {

			// SQL���̐���
			sqlBuffer.append("insert ");
			sqlBuffer.append("into emp_address_info ");
			sqlBuffer.append("values ");
			sqlBuffer.append("(?");
			sqlBuffer.append(",?");
			sqlBuffer.append(",?");
			sqlBuffer.append(",?");
			sqlBuffer.append(",?");
			sqlBuffer.append(",?");
			sqlBuffer.append(",?");
			sqlBuffer.append(",?");
			sqlBuffer.append(",default");
			sqlBuffer.append(",?");
			sqlBuffer.append(",default)");

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			// �v���y�A�[�h�X�e�[�g�����g�̍쐬
			ps = conn.prepareStatement(sqlBuffer.toString());

			// �l���Z�b�g
			ps.setString(1, insertBean.getEmpNo());
			ps.setString(2, insertBean.getPostCd1() + "-"
					+ insertBean.getPostCd2());
			ps.setString(3, insertBean.getAddressPref());
			ps.setString(4, insertBean.getAddressMunic());
			ps.setString(5, insertBean.getAddressAddr());
			ps.setString(6, insertBean.getAddressApart());
			ps.setString(7, insertBean.getTelNo1() + "-"
					+ insertBean.getTelNo2() + "-" + insertBean.getTelNo3());
			ps.setString(8, insertBean.getStation());
			ps.setString(9, name);

			// SQL���s
			int up = ps.executeUpdate();

			if (logger.isDebugEnabled()) {
				logger.debug("�Z�����\insert���s����");
			}
			// �ꌏ�ł��擾�ł����true
			if (up > 0) {
				flg = true;
			} else {
				flg = false;
			}
			return flg;
		} catch (SQLException e) {
			logger.error(ErrorConst.ERRORS_SQL);
			throw e;
		} catch (Exception e) {
			logger.error(ErrorConst.ERRORS_FATAL);
			throw e;
		} finally {

			// // DB�ؒf
			// this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);
		}

	}

	/**
	 * �]�ƈ��E�����i���e�[�u���œo�^���s��
	 *
	 * @param insertBean
	 * @param name
	 * @return true:�o�^���� false:�o�^���s
	 * @throws SQLException
	 * @throws Exception
	 */
	private boolean isInsertDutyInfo(InsertBean insertBean, String name)
			throws SQLException, Exception {
		logger.info(SettingConst.LOG_START);
		// ��`
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();
		boolean flg = false;

		try {

			// SQL���̐���
			sqlBuffer.append("insert ");
			sqlBuffer.append("into emp_duty_info ");
			sqlBuffer.append("values ");
			sqlBuffer.append("(?");
			sqlBuffer.append(",?");
			sqlBuffer.append(",default");
			sqlBuffer.append(",?");
			sqlBuffer.append(",default)");

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			// �v���y�A�[�h�X�e�[�g�����g�̍쐬
			ps = conn.prepareStatement(sqlBuffer.toString());

			// �l���Z�b�g
			ps.setString(1, insertBean.getEmpNo());
			ps.setString(2, insertBean.getDuty());
			ps.setString(3, name);

			// SQL���s
			int up = ps.executeUpdate();

			if (logger.isDebugEnabled()) {
				logger.debug("�E�����i�\insert���s����");
			}
			// �ꌏ�ł��擾�ł����true
			if (up > 0) {
				flg = true;
			} else {
				flg = false;
			}
			return flg;
		} catch (SQLException e) {
			logger.error(ErrorConst.ERRORS_SQL);
			throw e;
		} catch (Exception e) {
			logger.error(ErrorConst.ERRORS_FATAL);
			throw e;
		} finally {

			// // DB�ؒf
			// this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);
		}

	}

	/**
	 * �]�ƈ����Ǝ��i�e�[�u���œo�^���s��
	 *
	 * @param insertBean
	 * @param name
	 * @return true:�o�^���� false:�o�^���s
	 * @throws SQLException
	 * @throws Exception
	 */
	private boolean isInsertExamination(InsertBean insertBean, String name)
			throws SQLException, Exception {
		logger.info(SettingConst.LOG_START);
		// ��`
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();
		boolean flg = false;

		try {

			// SQL���̐���
			sqlBuffer.append("insert ");
			sqlBuffer.append("into emp_examination_info ");
			sqlBuffer.append("values ");
			sqlBuffer.append("(?");
			sqlBuffer.append(",?");
			sqlBuffer.append(",default");
			sqlBuffer.append(",?");
			sqlBuffer.append(",default)");

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			// �v���y�A�[�h�X�e�[�g�����g�̍쐬
			ps = conn.prepareStatement(sqlBuffer.toString());

			// �l���Z�b�g
			ps.setString(1, insertBean.getEmpNo());
			ps.setString(2, insertBean.getExaminationCd());
			ps.setString(3, name);
			System.out.println(insertBean.getExaminationCd());

			// SQL���s
			int up = ps.executeUpdate();

			if (logger.isDebugEnabled()) {
				logger.debug("���Ǝ��iinsert���s����");
			}
			// �ꌏ�ł��擾�ł����true
			if (up > 0) {
				flg = true;
			} else {
				flg = false;
			}
			return flg;
		} catch (SQLException e) {
			logger.error(ErrorConst.ERRORS_SQL);
			throw e;
		} catch (Exception e) {
			logger.error(ErrorConst.ERRORS_FATAL);
			throw e;
		} finally {

			// // DB�ؒf
			// this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);
		}

	}

}
