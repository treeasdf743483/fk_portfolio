package jp.co.cosmos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.co.cosmos.bean.*;
import jp.co.cosmos.common.ErrorConst;
import jp.co.cosmos.common.SettingConst;
import jp.co.cosmos.util.DBUtil;
import jp.co.cosmos.util.SafePassword;
import jp.co.cosmos.util.ValidateUtil;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ShowUpdateDao extends DBUtil {
	static Log logger = LogFactory.getLog(ShowInsertDao.class);
	public ShowUpdateDao() {
		logger.info(SettingConst.LOG_NEW);
	}

	/**
	 *DB���獑�Ǝ�����������Ă���
	 *
	 * @param userId
	 * @return
	 **/
	public List<ExamListBean> selectExaminationNm() throws SQLException,
			Exception {
		logger.info(SettingConst.LOG_START);
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();

		List<ExamListBean> examList = new ArrayList<ExamListBean>();

		try {
			conn = this.connectionDB();
			// SQL���̐���
			sqlBuffer.append("select ");
			sqlBuffer.append("examination_nm ");
			sqlBuffer.append(",examination_cd ");
			sqlBuffer.append("from ");
			sqlBuffer.append("examination ");
			sqlBuffer.append("order by sort_key asc  ");

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			ps = conn.prepareStatement(sqlBuffer.toString());

			// SQL���s
			rs = ps.executeQuery();

			if (logger.isDebugEnabled()) {
				logger.debug("SQL���s����");
			}

			// ���X�ƒl���擾
			while (rs.next()) {
				ExamListBean examBean = new ExamListBean();
				examBean.setExaminationNm(rs.getString("examination_nm"));
				examBean.setExaminationCd(rs.getString("examination_cd"));
				examList.add(examBean);

			}
			return examList;
		} catch (SQLException e) {

			throw e;
		} catch (Exception e) {

			throw e;
		} finally {
			// DB�ؒf
			this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);

		}

	}

	/**
	 *DB����E�����i��������Ă���
	 *
	 * @param userId
	 * @return
	 **/
	public List<DutyListBean> selectDutyNm() throws SQLException, Exception {
		logger.info(SettingConst.LOG_START);
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();

		List<DutyListBean> dutyList = new ArrayList<DutyListBean>();
		try {
			conn = this.connectionDB();
			// SQL���̐���
			sqlBuffer.append("select ");
			sqlBuffer.append("duty_nm ");
			sqlBuffer.append(",duty_cd ");
			sqlBuffer.append("from ");
			sqlBuffer.append("duty ");
			sqlBuffer.append("order by ");
			sqlBuffer.append("duty_cd asc ");

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			ps = conn.prepareStatement(sqlBuffer.toString());

			// SQL���s
			rs = ps.executeQuery();

			if (logger.isDebugEnabled()) {
				logger.debug("SQL���s����");
			}
			// ���X�ƒl���擾
			while (rs.next()) {
				DutyListBean dutyListBean = new DutyListBean();
				dutyListBean.setDutyNm(rs.getString("duty_nm"));
				dutyListBean.setDutyCd(rs.getString("duty_cd"));
				dutyList.add(dutyListBean);
			}
			return dutyList;
		} catch (SQLException e) {

			logger.error(ErrorConst.ERRORS_SQL, e);
			throw e;
		} catch (Exception e) {

			logger.fatal(ErrorConst.ERRORS_FATAL, e);
			throw e;
		} finally {
			// DB�ؒf
			this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);

		}
	}

	// select empNo whrere empNo = ?

	/**
	 * �]�ƈ���񑶍݃`�F�b�N
	 *
	 * @param userId
	 * @return boolean true ���� false ���݂��Ȃ�
	 */
	public ShowUpdateBean selectEmpNo(String userId) throws SQLException, Exception {

		logger.info(SettingConst.LOG_START);

		// ��`
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();

		// id��E�����i�R�[�h�Ə]�ƈ��ԍ��ɕ�����
		String dutyCd = userId.substring(SettingConst.DUTY_CD_BIGIN,
				SettingConst.DUTY_CD_END);
		String employeeNo = userId.substring(SettingConst.EMP_NO_BIGIN,
				SettingConst.EMP_NO_END);
		ShowUpdateBean showUpdateBean = new ShowUpdateBean();

		try {
			conn = this.connectionDB();
			// SQL���̐���
			sqlBuffer.append("select ");
			sqlBuffer.append("user_id ");
			sqlBuffer.append(",last_name_kanji ");
			sqlBuffer.append(",first_name_kanji ");
			sqlBuffer.append(",last_name_kana ");
			sqlBuffer.append(",first_name_kana ");
			sqlBuffer.append(",gender ");
			sqlBuffer.append(",birth ");
			sqlBuffer.append(",join_date ");
			sqlBuffer.append(",duty_nm ");
			sqlBuffer.append(",post_cd ");
			sqlBuffer.append(",address_pref ");
			sqlBuffer.append(",address_munic ");
			sqlBuffer.append(",address_addr ");
			sqlBuffer.append(",address_apart ");
			sqlBuffer.append(",tel_no ");
			sqlBuffer.append(",nearest_station ");
			sqlBuffer.append(",examination_nm ");
			sqlBuffer.append("from ");
			sqlBuffer.append("emp_basic_info ");
			sqlBuffer.append(",emp_address_info ");
			sqlBuffer.append(",emp_duty_info ");
			sqlBuffer.append(",emp_examination_info ");
			sqlBuffer.append(",duty ");
			sqlBuffer.append(",examination ");
			sqlBuffer.append("where ");
			sqlBuffer.append("emp_basic_info.emp_no=emp_address_info.emp_no  ");
			sqlBuffer.append("and emp_address_info.emp_no=emp_duty_info.emp_no ");
			sqlBuffer.append("and emp_address_info.emp_no=emp_examination_info.emp_no ");
			sqlBuffer.append("and emp_duty_info.duty_cd=duty.duty_cd");
			sqlBuffer.append("and emp_examination_info.examination_cd=examination.examination_cd ");
			sqlBuffer.append("where emp_duty_info.emp_no=? ");
			sqlBuffer.append("and emp_duty_info.duty_cd=? ");
			// ���O(�v���y�A�̑O�ŏo����)
			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}
			ps = conn.prepareStatement(sqlBuffer.toString());

			// �l���Z�b�g
			ps.setString(1, employeeNo);
			ps.setString(2, dutyCd);

			// SQL���s
			rs = ps.executeQuery();

			if (logger.isDebugEnabled()) {
				logger.debug("SQL���s����");
			}

			while (rs.next()) {

				showUpdateBean.setEmpNo(rs.getString("duty_cd") + rs.getString("user_id"));
				showUpdateBean.setFirstNameKanji(rs.getString("first_name_kanji"));
				showUpdateBean.setLastNameKanji(rs.getString("last_name_kanji"));
				showUpdateBean.setFirstNameKana(rs.getString("first_name_kana"));
				showUpdateBean.setLastNameKana(rs.getString("last_name_kana"));
				showUpdateBean.setGender(rs.getString("gender"));
				showUpdateBean.setBirthYear((rs.getString(ValidateUtil.changeToEraFromDate(rs.getString("birth").substring(0,4)))));
				showUpdateBean.setBirthEra((rs.getString(ValidateUtil.calEra(rs.getString("birth").substring(0,4)))));
				showUpdateBean.setBirthMonth((rs.getString("birth").substring(5,7)));
				showUpdateBean.setBirthDay(rs.getString("birth").substring(8,10));
				showUpdateBean.setJoinYear((rs.getString(ValidateUtil.changeToEraFromDate(rs.getString("join_date").substring(0,4)))));
				showUpdateBean.setJoinEra((rs.getString(ValidateUtil.calEra(rs.getString("join_date").substring(0,4)))));
				showUpdateBean.setJoinMonth((rs.getString("join_date").substring(5,7)));
				showUpdateBean.setJoinDay(rs.getString("join_date").substring(8,10));
				showUpdateBean.setDutyNm(rs.getString("duty_nm"));
				showUpdateBean.setAddressPref(rs.getString("address_pref"));
				showUpdateBean.setAddressMunic(rs.getString("address_munic"));
				showUpdateBean.setAddressAddr(rs.getString("address_addr"));
				showUpdateBean.setAddressApart(rs.getString("address_apart"));
				showUpdateBean.setTelNo1(rs.getString("tel_no").substring(0,3));
				showUpdateBean.setTelNo2(rs.getString("tel_no").substring(4,8));
				showUpdateBean.setTelNo3(rs.getString("tel_no").substring(9));
				showUpdateBean.setExaminationNm(rs.getString("examination_nm"));
				showUpdateBean.setStation(rs.getString("nearest_station"));
			}


		} catch (SQLException e) {

			throw e;
		} catch (Exception e) {

			throw e;
		} finally {

			// DB�ؒf
			this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);
		}

		return showUpdateBean;

	}
}
