function getPassMenu(){
	location.href="Modoru.do";
}