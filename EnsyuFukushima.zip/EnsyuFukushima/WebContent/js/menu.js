//function dialogue(){
//	ret = confirm();
//	if (ret == true){
//		location.href = "/EnsyuFukushima/logout.do";
//	}
//}
