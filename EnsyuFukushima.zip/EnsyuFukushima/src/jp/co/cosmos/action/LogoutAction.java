package jp.co.cosmos.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class LogoutAction extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

	// �Z�b�V�������擾
	HttpSession session = ((HttpServletRequest) request).getSession();
	// �Z�b�V������j��
	session.invalidate();

	// ���O�C����ʂ֖߂�
	return mapping.findForward("success");
	}
}
