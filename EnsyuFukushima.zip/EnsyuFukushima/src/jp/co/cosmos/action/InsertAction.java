package jp.co.cosmos.action;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.cosmos.form.InsertForm;
import jp.co.cosmos.bean.LoginBean;
import jp.co.cosmos.common.ErrorConst;
import jp.co.cosmos.common.ResourseKeyConst;

import jp.co.cosmos.common.SettingConst;

import jp.co.cosmos.dao.InsertDao;
import jp.co.cosmos.dao.ExistEmpNoDao;
import jp.co.cosmos.dao.ExistEmpNoDelFlgDao;
import jp.co.cosmos.bean.InsertBean;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
/**
 *
 * @author �����\�C �쐬�� 2014/6/6
 *
 */
public class InsertAction extends Action {

	// ���O���`
	static Log logger = LogFactory.getLog(LoginAction.class);

	/**
	 * �]�ƈ����̓o�^
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
	HttpServletRequest request, HttpServletResponse response) throws Exception {
		// ��`
		InsertForm insertForm = (InsertForm) form;
		System.out.println("��" + insertForm.getEmpNo());
		InsertDao insertDao = new InsertDao();
		ExistEmpNoDao existDao = new ExistEmpNoDao();
		ExistEmpNoDelFlgDao existDaoDelFlg = new ExistEmpNoDelFlgDao();
		ActionMessages messages = new ActionMessages();
		ActionErrors errors = new ActionErrors();
		// �C���X�^���X����
		InsertBean insertBean = new InsertBean();
		LoginBean loginBean = new LoginBean();
		logger.info(SettingConst.LOG_START);

		try {
			//Bean�̒��g���R�s�[
			BeanUtils.copyProperties(insertBean, insertForm);
			// ���݊m�F�`�F�b�N1
			if (existDao.isExistEmpNo(insertForm.getEmpNo())) {
				// ���݊m�F�`�F�b�N2
				if (existDaoDelFlg.isExistEmpNoDelFlg(insertForm.getEmpNo())) {

					HttpSession session = ((HttpServletRequest) request)
							.getSession();
					loginBean = (LoginBean) session
							.getAttribute(SettingConst.LOGIN_BEAN_KEY);
					// �o�^�`�F�b�N
					if (insertDao.isEnroll(insertBean, loginBean.getName())) {
						logger.info(SettingConst.MESSEGE_SUCCESS);
						logger.info(SettingConst.LOG_END);
						messages.add(ActionMessages.GLOBAL_MESSAGE,
								new ActionMessage(
										ResourseKeyConst.REGISTER_SUCCESS));
						saveMessages(request, messages);

						return mapping.findForward(SettingConst.ENLIST_SUCCESS);
					} else {

						messages.add(ActionMessages.GLOBAL_MESSAGE,
								new ActionMessage(
										ResourseKeyConst.REGISTER_FAILURE));
						saveMessages(request, messages);

						logger.info(SettingConst.MESSEGE_FAILURE);
						logger.info(SettingConst.LOG_END);
						return mapping.getInputForward();
					}
				} else {
					errors.add(ActionMessages.GLOBAL_MESSAGE,
							new ActionMessage(ResourseKeyConst.EXIST2_ERROR));
					logger.info(SettingConst.EXIST2_ERROR);
					logger.info(SettingConst.LOG_END);
					saveErrors(request,errors);
					return mapping.getInputForward();
				}
			} else {
				errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(
						ResourseKeyConst.EXIST1_ERROR));
				saveErrors(request,errors);
				logger.info(SettingConst.EXIST1_ERROR);
				return mapping.getInputForward();
			}
		} catch (SQLException e) {
			logger.error(ErrorConst.ERRORS_SQL, e);

			request.setAttribute(SettingConst.SYSTEM_ERROR, e);
			request.setAttribute("errorDetail",e.getStackTrace());
			return mapping.findForward(SettingConst.ERROR_KEY);
		} catch (Exception e) {
			logger.fatal(ErrorConst.ERRORS_FATAL, e);

			request.setAttribute(SettingConst.ERROR_KEY, e);
			request.setAttribute("errorDetail",e.getStackTrace());
			return mapping.findForward(SettingConst.ERROR_KEY);
		} finally {
			logger.info(SettingConst.LOG_END);
		}
	}
}
