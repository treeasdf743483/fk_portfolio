#include "DIRECTOR.h"

//
//
//
DIRECTOR::DIRECTOR()
{
	ZeroMemory(this,sizeof(DIRECTOR));
	m_Scene=PLAY_STAGE1;
	m_iNumMonster=MAX_MONSTER;
}
//
//
//
DIRECTOR::~DIRECTOR()
{
	SAFE_DELETE(m_pCamera);
	SAFE_DELETE(m_pFieldMesh);
	SAFE_DELETE(m_pHito);
	SAFE_DELETE(m_pShotMesh);
	for(int i=0;i<MAX_MONSTER;i++) SAFE_DELETE(m_pMonster[i]);
	SAFE_DELETE(m_pD3d);
	SAFE_DELETE(m_pWindow);
	SAFE_DELETE(m_pSound);
}
//
//
//
void DIRECTOR::Run(HINSTANCE hInstance)
{
	WCHAR dir[1024];
	GetCurrentDirectory(sizeof(dir),dir);
	InitDirectory(dir);

	m_hInstance=hInstance;
	if(FAILED(Init()))
	{
		return;
	}
	ShowWindow(m_hWnd,SW_SHOW);
	UpdateWindow(m_hWnd) ;
	// ���b�Z�[�W���[�v
	MSG msg={0};
	ZeroMemory(&msg,sizeof(msg));
	while(msg.message!=WM_QUIT)
	{
		if( PeekMessage(&msg,NULL,0,0,PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			MainLoop();
		}
	}
}
//
//
//
void DIRECTOR::MainLoop()
{
	m_pD3d->Clear();
	switch(m_Scene)
	{
		case OPENING:
		break;
		case PLAY_STAGE1:
			Stage1();
		break;
		case WIN:
			Win();
		break;
		case GAMEOVER:
			GameOver();
		break;
	}
	FixFPS60();
	m_pD3d->Present();
}
//
//
//
HRESULT DIRECTOR::Init()
{
	//window
	m_pWindow=new WINDOW;
	if(!m_pWindow)
	{
		return E_FAIL;
	}
	MFAIL(m_pWindow->InitWindow(m_hInstance,0,0,WINDOW_WIDTH,WINDOW_HEIGHT,APP_NAME),L"�E�B���h�E�쐬���s");
	m_hWnd=m_pWindow->m_hWnd;
	//direct3D10
	D3D_INIT di;
	m_pD3d=new DIRECT3D10;
	if(m_pD3d==NULL)
	{
		MSG(L"Direct3D�̏��������s");
		return E_FAIL;
	}
	di.hWnd=m_hWnd;
	MFAIL(m_pD3d->Init(&di),L"Direct3D���������s");

	//camera
	m_pCamera=new CAMERA;
	m_pCamera->Init(WINDOW_WIDTH,WINDOW_HEIGHT);
	m_pCamera->SetCameraPosition(0,0,-1);

	//field mesh
	m_pFieldMesh=new MESH;
	m_pFieldMesh->Init(m_pD3d);
	MFAIL(m_pFieldMesh->InitStaticMesh("field.obj"),L"�t�B�[���h�ǂݍ��ݎ��s");
	m_pFieldMesh->m_vPos=D3DXVECTOR3(0,0,0);
	//shot mesh
	m_pShotMesh=new MESH;
	m_pShotMesh->Init(m_pD3d);
	MFAIL(m_pShotMesh->InitStaticMesh("shot.obj"),L"�e �ǂݍ��ݎ��s");
	m_pShotMesh->m_vPos=D3DXVECTOR3(0,0,0);
	// Hito skin mesh
	m_pHito=new CHARACTER;
	m_pHito->Init(m_pD3d);
	MFAIL(m_pHito->CreateFromFBX("hito.fbx"),L"��l���ǂݍ��ݎ��s");
	m_pHito->m_vPos=D3DXVECTOR3(0,5,0);
	// Monster skin mesh
	for(int i=0;i<MAX_MONSTER;i++)
	{
		m_pMonster[i]=new CHARACTER;
		m_pMonster[i]->Init(m_pD3d);
		MFAIL(m_pMonster[i]->CreateFromFBX("buyobuyo.fbx"),L"��l���ǂݍ��ݎ��s");
		float x=((float)rand()/(float)RAND_MAX)*20.0f-10.0f;
		float y=((float)rand()/(float)RAND_MAX)*20.0f-10.0f;
		m_pMonster[i]->m_vPos=D3DXVECTOR3(x,10,y);
	}
	//Sound(XAuido2)
	m_pSound=new SOUND;
	MFAIL(m_pSound->Init(),L"�T�E���h���������s");

	SetSoundDirectory();
	m_iBGMSound=m_pSound->LoadSound("bgm.wav");	
	for(int i=0;i<5;i++)	m_iFireSound[i]=m_pSound->LoadSound("fire.wav");
	m_iHitSound=m_pSound->LoadSound("hit.wav");
	m_iGameOverSound=m_pSound->LoadSound("gameover.wav");

	m_pSound->PlaySound(m_iBGMSound,true);

	return S_OK;
}
//
//
//
void DIRECTOR::Reset()
{
	m_Scene=PLAY_STAGE1;
	m_pHito->m_vPos=D3DXVECTOR3(0,5,0);
	m_pHito->m_fYaw=0;
	m_iNumShot=0;
	m_iNumMonster=MAX_MONSTER;
	for(int i=0;i<MAX_MONSTER;i++)
	{
		float x=((float)rand()/(float)RAND_MAX)*20.0f-10.0f;
		float y=((float)rand()/(float)RAND_MAX)*20.0f-10.0f;
		m_pMonster[i]->m_vPos=D3DXVECTOR3(x,10,y);
		m_pMonster[i]->m_iWait=0;
		m_pMonster[i]->m_vTargetDir=D3DXVECTOR3(0,0,0);
	}
}
//
//
//
void DIRECTOR::FixFPS60()
{
	static INT Frames=0,FPS=0;
	static LARGE_INTEGER Frq={0},PreviousTime={0},CurrentTime={0};
	DOUBLE Time=0;
	char sz[10]={0};

	while(Time<16.6666)//1000ms / 60frame=16.6666 
	{
		QueryPerformanceFrequency(&Frq);
		
		QueryPerformanceCounter(&CurrentTime);
		Time=CurrentTime.QuadPart-PreviousTime.QuadPart;
		Time *=(DOUBLE)1000.0 / (DOUBLE)Frq.QuadPart;		
	}
	PreviousTime=CurrentTime;
}