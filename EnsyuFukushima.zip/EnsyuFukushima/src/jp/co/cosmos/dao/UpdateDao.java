package jp.co.cosmos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jp.co.cosmos.bean.InsertBean;
import jp.co.cosmos.bean.UpdateBean;
import jp.co.cosmos.common.ErrorConst;
import jp.co.cosmos.common.SettingConst;
import jp.co.cosmos.util.DBUtil;
import jp.co.cosmos.util.SafePassword;
import jp.co.cosmos.util.ValidateUtil;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class UpdateDao extends DBUtil{
	// ���O�̒�`
	static Log logger = LogFactory.getLog(InsertDao.class);

	private Connection conn = null;
	public UpdateDao() {
		logger.info(SettingConst.LOG_NEW);
	}

	/**
	 * �o�^�����`�F�b�N
	 *
	 * @param insertBean
	 * @param name
	 * @return true:�o�^���� false:�o�^���s
	 * @throws SQLException
	 * @throws Exception
	 */
	public boolean isUpdate(UpdateBean updateBean, String name)
			throws SQLException, Exception {

		logger.info(SettingConst.LOG_START);
		try {
			conn = this.connectionDB();
			// �I�[�g�R�~�b�g�����Ȃ�
			conn.setAutoCommit(false);
			// �S�e�[�u���œo�^�m�F�`�F�b�N
			if (isUpdateBasicInfo(updateBean, name)
					&& isUpdateAddressInfo(updateBean, name)
					&& isUpdateDutyInfo(updateBean, name)) {
				conn.commit();
				return true;
			} else {
				conn.rollback();
				return false;

			}
		} catch (SQLException e) {
			logger.error(ErrorConst.ERRORS_SQL);
			throw e;
		} catch (Exception e) {
			logger.error(ErrorConst.ERRORS_FATAL);
			throw e;
		} finally {

			// DB�ؒf
			this.close(conn);
			logger.info(SettingConst.LOG_END);
		}
	}

	/**
	 * �]�ƈ���{���e�[�u���œo�^���s��
	 *
	 * @param updateBean
	 * @param name
	 * @return true:�o�^���� false:�o�^���s
	 * @throws SQLException
	 * @throws Exception
	 */
	private boolean isUpdateBasicInfo(UpdateBean updateBean, String name)
			throws SQLException, Exception {
		logger.info(SettingConst.LOG_START);
		// ��`
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();
		boolean flg = false;

		try {
			// SQL���̐���
			sqlBuffer.append("update ");
			sqlBuffer.append("emp_basic_info ");
			sqlBuffer.append("set ");
			sqlBuffer.append("last_name_kanji=?,");
			sqlBuffer.append("first_name_kanji=?,");
			sqlBuffer.append("last_name_kana=?,");
			sqlBuffer.append("first_name_kana=?,");
			sqlBuffer.append("birth=?,");
			sqlBuffer.append("gender=?,");
			sqlBuffer.append("family_register=?,");
			sqlBuffer.append("join_date=?,");
			sqlBuffer.append("update_date=default,");
			sqlBuffer.append("update_emp=? ");
			sqlBuffer.append("where emp_no=?;");

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			// �v���y�A�[�h�X�e�[�g�����g�̍쐬
			ps = conn.prepareStatement(sqlBuffer.toString());

			// �l���Z�b�g
			ps.setString(1, updateBean.getLastNameKanji());
			ps.setString(2, updateBean.getFirstNameKanji());
			ps.setString(3, updateBean.getLastNameKana());
			ps.setString(4, updateBean.getFirstNameKana());
			ps.setString(5, ValidateUtil.changeToDateFromEra(updateBean
					.getBirthEra(), updateBean.getBirthYear(), updateBean
					.getBirthMonth(), updateBean.getBirthDay()));
			ps.setString(6, updateBean.getGender());
			ps.setString(7, updateBean.getFamilyRegister());
			ps.setString(8, ValidateUtil.changeToDateFromEra(updateBean
					.getJoinEra(), updateBean.getJoinYear(), updateBean
					.getJoinMonth(), updateBean.getJoinDay()));
			ps.setString(9,name);
			ps.setString(10,updateBean.getEmpNo());

			// SQL���s
			int up = ps.executeUpdate();

			if (logger.isDebugEnabled()) {
				logger.debug("��{���\insert���s����");
			}
			// �ꌏ�ł��擾�ł����true
			if (up > 0) {
				flg = true;
			} else {
				flg = false;
			}
			return flg;
		} catch (SQLException e) {
			logger.error(ErrorConst.ERRORS_SQL);
			throw e;
		} catch (Exception e) {
			logger.error(ErrorConst.ERRORS_FATAL);
			throw e;
		} finally {

			// // DB�ؒf
			// this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);
		}

	}

	/**
	 * �]�ƈ��Z�����e�[�u���œo�^���s��
	 *
	 * @param updateBean
	 * @param name
	 * @return true:�o�^���� false:�o�^���s
	 * @throws SQLException
	 * @throws Exception
	 */
	private boolean isUpdateAddressInfo(UpdateBean updateBean, String name)
			throws SQLException, Exception {
		logger.info(SettingConst.LOG_START);
		// ��`
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();
		boolean flg = false;

		try {

			// SQL���̐���
			sqlBuffer.append("update ");
			sqlBuffer.append("emp_address_info ");
			sqlBuffer.append("set ");
			sqlBuffer.append("post_cd=? ");
			sqlBuffer.append(",address_pref=? ");
			sqlBuffer.append(",address_munic=? ");
			sqlBuffer.append(",address_addr=? ");
			sqlBuffer.append(",address_apart=? ");
			sqlBuffer.append(",tel_no=? ");
			sqlBuffer.append(",nearest_station=? ");
			sqlBuffer.append(",update_date=default ");
			sqlBuffer.append(",update_emp=? ");
			sqlBuffer.append("where emp_no=?;");


			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			// �v���y�A�[�h�X�e�[�g�����g�̍쐬
			ps = conn.prepareStatement(sqlBuffer.toString());

			// �l���Z�b�g
			ps.setString(1, updateBean.getPostCd1() + "-"
					+ updateBean.getPostCd2());
			ps.setString(2, updateBean.getAddressPref());
			ps.setString(3, updateBean.getAddressMunic());
			ps.setString(4, updateBean.getAddressAddr());
			ps.setString(5, updateBean.getAddressApart());
			ps.setString(6, updateBean.getTelNo1() + "-"
					+ updateBean.getTelNo2() + "-" + updateBean.getTelNo3());
			ps.setString(7, updateBean.getStation());
			ps.setString(8, name);
			ps.setString(9,updateBean.getEmpNo());

			// SQL���s
			int up = ps.executeUpdate();

			if (logger.isDebugEnabled()) {
				logger.debug("�Z�����\insert���s����");
			}
			// �ꌏ�ł��擾�ł����true
			if (up > 0) {
				flg = true;
			} else {
				flg = false;
			}
			return flg;
		} catch (SQLException e) {
			logger.error(ErrorConst.ERRORS_SQL);
			throw e;
		} catch (Exception e) {
			logger.error(ErrorConst.ERRORS_FATAL);
			throw e;
		} finally {

			// // DB�ؒf
			// this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);
		}

	}

	/**
	 * �]�ƈ��E�����i���e�[�u���œo�^���s��
	 *
	 * @param updateBean
	 * @param name
	 * @return true:�o�^���� false:�o�^���s
	 * @throws SQLException
	 * @throws Exception
	 */
	private boolean isUpdateDutyInfo(UpdateBean updateBean, String name)
			throws SQLException, Exception {
		logger.info(SettingConst.LOG_START);
		// ��`
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();
		boolean flg = false;

		try {

			// SQL���̐���
			sqlBuffer.append("update ");
			sqlBuffer.append("emp_duty_info ");
			sqlBuffer.append("set ");
			sqlBuffer.append("duty_cd=? ");
			sqlBuffer.append(",update_date=default ");
			sqlBuffer.append(",update_emp=? ");
			sqlBuffer.append("where emp_no=?;");

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			// �v���y�A�[�h�X�e�[�g�����g�̍쐬
			ps = conn.prepareStatement(sqlBuffer.toString());

			// �l���Z�b�g
			ps.setString(1, updateBean.getDutyCd());
			ps.setString(2, name);
			ps.setString(3,updateBean.getEmpNo());

			// SQL���s
			int up = ps.executeUpdate();

			if (logger.isDebugEnabled()) {
				logger.debug("�E�����i�\insert���s����");
			}
			// �ꌏ�ł��擾�ł����true
			if (up > 0) {
				flg = true;
			} else {
				flg = false;
			}
			return flg;
		} catch (SQLException e) {
			logger.error(ErrorConst.ERRORS_SQL);
			throw e;
		} catch (Exception e) {
			logger.error(ErrorConst.ERRORS_FATAL);
			throw e;
		} finally {

			// // DB�ؒf
			// this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);
		}

	}

	/**
	 * �]�ƈ����Ǝ��i�e�[�u���œo�^���s��
	 *
	 * @param updateBean
	 * @param name
	 * @return true:�o�^���� false:�o�^���s
	 * @throws SQLException
	 * @throws Exception
	 */
	public void vUpdateExamination(String strExaminationNm,UpdateBean updateBean, String name)
			throws SQLException, Exception {
		logger.info(SettingConst.LOG_START);
		// ��`
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();
		boolean flg = false;
		conn = this.connectionDB();

		try {
			System.out.println(updateBean.getExaminationCd());
			// SQL���̐���
			sqlBuffer.append("insert into emp_examination_info values (?,?,default,?,default); ");

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			// �v���y�A�[�h�X�e�[�g�����g�̍쐬
			ps = conn.prepareStatement(sqlBuffer.toString());

			// �l���Z�b�g
			ps.setString(1,updateBean.getEmpNo());
			ps.setString(2,strExaminationNm);
			ps.setString(3,name);

			// SQL���s
			int up = ps.executeUpdate();

			if (logger.isDebugEnabled()) {
				logger.debug("���Ǝ��iinsert���s����");
			}
			// �ꌏ�ł��擾�ł����true
			if (up > 0) {
				flg = true;
			} else {
				flg = false;
			}
		} catch (SQLException e) {
			logger.error(ErrorConst.ERRORS_SQL);
			throw e;
		} catch (Exception e) {
			logger.error(ErrorConst.ERRORS_FATAL);
			throw e;
		} finally {

			// // DB�ؒf
			// this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);
		}

	}


	/**
	 * �]�ƈ����Ǝ��i�e�[�u���œo�^���s��
	 *
	 * @param updateBean
	 * @param name
	 * @return true:�o�^���� false:�o�^���s
	 * @throws SQLException
	 * @throws Exception
	 */
	public void deleteExamination(UpdateBean updateBean)
			throws SQLException, Exception {
		logger.info(SettingConst.LOG_START);
		// ��`
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();
		boolean flg = false;
		System.out.println("getEmp" + updateBean.getEmpNo());
		conn = this.connectionDB();

		try {
			// SQL���̐���
			sqlBuffer.append("delete from emp_examination_info where emp_no=? ");

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			// �v���y�A�[�h�X�e�[�g�����g�̍쐬
			ps = conn.prepareStatement(sqlBuffer.toString());

			ps.setString(1,updateBean.getEmpNo());


			// SQL���s
			int up = ps.executeUpdate();

			if (logger.isDebugEnabled()) {
				logger.debug("���Ǝ��iinsert���s����");
			}
			// �ꌏ�ł��擾�ł����true
			if (up > 0) {
				flg = true;
			} else {
				flg = false;
			}

		} catch (SQLException e) {
			logger.error(ErrorConst.ERRORS_SQL);
			throw e;
		} catch (Exception e) {
			logger.error(ErrorConst.ERRORS_FATAL);
			throw e;
		} finally {

			// // DB�ؒf
			// this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);
		}

	}
}
