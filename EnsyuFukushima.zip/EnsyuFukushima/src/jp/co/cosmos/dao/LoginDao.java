package jp.co.cosmos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import jp.co.cosmos.bean.LoginBean;
import jp.co.cosmos.common.SettingConst;
import jp.co.cosmos.util.DBUtil;
import jp.co.cosmos.util.SafePassword;
/**
 *DB�����N���X
 *
 * @author �����\�C �쐬�� 2014/05/16
 */
public class LoginDao extends DBUtil {

	static Log logger = LogFactory.getLog(LoginDao.class);

	public LoginDao() {
		logger.info(SettingConst.LOG_NEW);
	}

	/**
	 * �]�ƈ���񑶍݃`�F�b�N
	 *
	 * @param userId
	 * @return boolean true ���� false ���݂��Ȃ�
	 */
	public boolean isMatchLoginInfo(String userId, String password)
			throws SQLException, Exception {
		logger.info(SettingConst.LOG_START);

		// ��`
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();
		boolean flg = false;

		// id��E�����i�R�[�h�Ə]�ƈ��ԍ��ɕ�����
		String dutyCd = userId.substring(SettingConst.DUTY_CD_BIGIN,
				SettingConst.DUTY_CD_END);
		String employeeNo = userId.substring(SettingConst.EMP_NO_BIGIN,
				SettingConst.EMP_NO_END);

		try {
			conn = this.connectionDB();
			logger.info(SettingConst.CONNECTION_OPEN);
			String stretchedPassword = SafePassword
					.getStretchedPassword(employeeNo + password + "cosmos");
			// SQL���̐���
			sqlBuffer.append("select ");
			sqlBuffer.append("duty_cd ");
			sqlBuffer.append(",emp_basic_info.emp_no ");
			sqlBuffer.append("from ");
			sqlBuffer.append("emp_duty_info ");
			sqlBuffer.append(",login ");
			sqlBuffer.append(",emp_address_info ");
			sqlBuffer.append(",emp_basic_info ");
			sqlBuffer.append(",emp_examination_info ");
			sqlBuffer.append("where ");
			sqlBuffer.append(" emp_duty_info.duty_cd=? ");
			sqlBuffer.append(" and emp_duty_info.emp_no=? ");
			sqlBuffer.append(" and login.password=? ");
			sqlBuffer.append(" and emp_basic_info.emp_no=emp_address_info.emp_no ");
			sqlBuffer.append(" and emp_basic_info.emp_no=emp_duty_info.emp_no ");
			sqlBuffer.append(" and emp_basic_info.emp_no=login.user_id ");
			sqlBuffer.append(" and emp_basic_info.emp_no=emp_examination_info.emp_no ");
			sqlBuffer.append(" and emp_basic_info.del_flg='0' ");
			sqlBuffer.append(" and login.del_flg='0' ");
			sqlBuffer.append(" and emp_duty_info.del_flg='0' ");
			sqlBuffer.append(" and emp_address_info.del_flg='0' ");
			sqlBuffer.append(" and emp_address_info.del_flg='0' ");
			sqlBuffer.append(" and emp_examination_info.del_flg='0' ");
			// sqlBuffer.append("and emp_duty_info.del_flg=0 ");

			// ���O(�v���y�A�̑O�ŏo����)
			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}
			ps = conn.prepareStatement(sqlBuffer.toString());

			// �l���Z�b�g
			ps.setString(1, dutyCd);
			ps.setString(2, employeeNo);
			ps.setString(3, stretchedPassword);

			// SQL���s
			rs = ps.executeQuery();

			if (logger.isDebugEnabled()) {
				logger.debug("SQL���s����");
			}

			flg = rs.next();

		} catch (SQLException e) {

			throw e;
		} catch (Exception e) {

			throw e;
		} finally {

			// DB�ؒf
			this.close(conn);
			logger.info(SettingConst.CONNECTION_CLOSE);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);
		}

		return flg;

	}

	/**
	 * �Z�b�V�����Ƃ���]�ƈ������擾����
	 *
	 * @param userId
	 * @return LoginBean �o��Bean
	 */
	public LoginBean loginInfo(String userId) throws SQLException, Exception {

		logger.info(SettingConst.LOG_START);
		// ��`
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();
		LoginBean loginBean = new LoginBean();
		String employeeNo = userId.substring(SettingConst.EMP_NO_BIGIN,
				SettingConst.EMP_NO_END);

		try {
			conn = this.connectionDB();
			// SQL���̐���
			sqlBuffer.append("select ");
			sqlBuffer.append("auth_flg ");
			sqlBuffer.append(",user_id ");
			sqlBuffer.append(",first_name_kanji ");
			sqlBuffer.append(",last_name_kanji ");
			sqlBuffer.append(",duty_cd ");
			sqlBuffer.append("from ");
			sqlBuffer.append("login ");
			sqlBuffer.append(",emp_basic_info ");
			sqlBuffer.append(",emp_duty_info ");
			sqlBuffer.append("where ");
			sqlBuffer.append("emp_basic_info.emp_no=emp_duty_info.emp_no ");
			sqlBuffer.append("and emp_basic_info.emp_no=login.user_id ");
			sqlBuffer.append("and login.user_id=? ");
			// sqlBuffer.append("and emp_basic_info.del_flg=0 ");

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			// �v���y�A�[�h�X�e�[�g�����g�̍쐬
			ps = conn.prepareStatement(sqlBuffer.toString());

			// SQL�ɒl���Z�b�g
			ps.setString(1, employeeNo);

			// SQL���s
			rs = ps.executeQuery();

			if (logger.isDebugEnabled()) {
				logger.debug("SQL���s����");
			}

			// select�����S�������X�Ɖ�
			while (rs.next()) {
				loginBean.setEmployeeNo(rs.getString("user_id"));
				loginBean.setAuthFlg(rs.getString("auth_flg"));
				loginBean.setDutyCd(rs.getString("duty_cd"));
				loginBean.setName(rs.getString("last_name_kanji")
						+ rs.getString("first_name_kanji"));
				if (logger.isDebugEnabled()) {
					logger.debug(loginBean.getAuthFlg());
					logger.debug(loginBean.getDutyCd());
					logger.debug(loginBean.getEmployeeNo());
					logger.debug(loginBean.getName());
				}

			}

		} catch (SQLException e) {

			throw e;
		} catch (Exception e) {

			throw e;
		} finally {
			// DB�ؒf
			this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);
		}

		return loginBean;
	}
}
