function checkForm() {

	var errorMsg = "" ;
	if (document.loginForm.userId.value=="") {
		errorMsg = errorMsg + "ユーザIDを入力して下さい<br>";

	}
	else if (!(document.loginForm.userId.value.match(/^[0-9]*$/))) {
		errorMsg = errorMsg + "ユーザIDは半角数字で入力して下さい<br>";

	}
	if (document.loginForm.userId.value.length != 4) {
		errorMsg = errorMsg + "ユーザーIDは４桁で入力して下さい<br>";

	}
	if (document.loginForm.password.value == "") {
		errorMsg = errorMsg + "パスワードを入力して下さい<br>";

	}
	else if (!(document.loginForm.password.value.match(/^[0-9a-zA-Z]*$/))) {
		errorMsg = errorMsg + "パスワードは半角英数字で入力して下さい<br>";

	}

	if(errorMsg != ""){
		document.getElementById("error").innerHTML = errorMsg;
		return false;
	}
}


