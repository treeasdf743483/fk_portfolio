package jp.co.cosmos.action;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import jp.co.cosmos.form.SearchForm;
import jp.co.cosmos.util.ListUtil;
import jp.co.cosmos.common.ErrorConst;
import jp.co.cosmos.common.ResourseKeyConst;
import jp.co.cosmos.common.SettingConst;
import jp.co.cosmos.common.StrConst;
import jp.co.cosmos.dao.SearchDao;
import jp.co.cosmos.bean.DutyListBean;
import jp.co.cosmos.bean.EraBean;
import jp.co.cosmos.bean.ExamListBean;
import jp.co.cosmos.bean.SearchBean;
import jp.co.cosmos.bean.TodoufukenBean;

/**
 *
 * @author �����\�C �쐬�� 2014/6/9
 *
 */
public class SearchAction extends Action {

	static Log logger = LogFactory.getLog(SearchAction.class);

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		//��`
		SearchForm searchForm = (SearchForm) form;
		SearchBean searchBean = new SearchBean();
		List<SearchBean> searchList = new ArrayList<SearchBean>();
		ActionErrors errors = new ActionErrors();
		List<DutyListBean> dutyNmList = new ArrayList<DutyListBean>();
		List<ExamListBean> examList = new ArrayList<ExamListBean>();
		List<EraBean> eraBean = new ArrayList<EraBean>();
		List<TodoufukenBean> todoufukenBean = new ArrayList<TodoufukenBean>();


		logger.info(SettingConst.LOG_START);

		try {
			//�]�ƈ����̌���
			SearchDao searchDao = new SearchDao();
			String[][] array = searchDao.selectExamEmpNo(searchForm.getEmpNo());
			System.out.println("�]�ƈ��ԍ���" + searchForm.getEmpNo());
			String[] examinationNmarray = array[0];
			String[] examinationCdarray = array[1];

			searchBean = searchDao.selectEmpInfo(searchForm.getEmpNo());
			searchBean.setExaminationNm(examinationNmarray);
			searchBean.setExaminationCd(examinationCdarray);
			searchBean.setDutyCd(searchDao.selectDutyCd(searchForm.getEmpNo()));

			searchBean.setUserId(searchForm.getEmpNo());
			examList = searchDao.selectExam();
			dutyNmList = searchDao.selectDutyNm();
			eraBean=ListUtil.getEraList();
			todoufukenBean = ListUtil.getTodoufukenList();
			System.out.println("addr" + searchBean.getAddressAddr());

			HttpSession session = request.getSession();

			String key2=(String)session.getAttribute("key");
	 		if(key2 == null || key2==""){
				return mapping.findForward(SettingConst.ENLIST_FAILURE);
			}

			if(searchBean.getCount() == 0){
				errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(
						ResourseKeyConst.EMPNO_ERROR));
				saveErrors(request,errors);
				logger.info(SettingConst.LOG_END);
				return mapping.getInputForward();

			}
		if(searchDao.isDutyCd(searchForm.getEmpNo())){
				// �J��
			request.setAttribute("searchBean", searchBean);
			//request.setAttribute("searchList", searchList);
			session.setAttribute("examinationNmList", examList);
			session.setAttribute("dutyNmList", dutyNmList);
			session.setAttribute("todoufukenList", ListUtil.getTodoufukenList());
			session.setAttribute("eraList", ListUtil.getEraList());

			logger.info(SettingConst.LOG_END);
			return mapping.findForward(SettingConst.ENLIST_SUCCESS);
			} else {
				errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(
						ResourseKeyConst.EMPNO_ERROR));
				saveErrors(request,errors);
				logger.info(SettingConst.LOG_END);
				return mapping.getInputForward();
			}

		} catch (SQLException e) {

			logger.error(ErrorConst.ERRORS_SQL, e);
			//�J��
			request.setAttribute("systemError", e);
			request.setAttribute("errorDetail",e.getStackTrace());
			logger.info(SettingConst.LOG_END);
			return mapping.findForward("error");
		} catch (Exception e) {

			logger.fatal(ErrorConst.ERRORS_FATAL, e);
			//�J��
			request.setAttribute("systemError", e);
			request.setAttribute("errorDetail",e.getStackTrace());
			logger.info(SettingConst.LOG_END);
			return mapping.findForward("error");
		}
	}
}
