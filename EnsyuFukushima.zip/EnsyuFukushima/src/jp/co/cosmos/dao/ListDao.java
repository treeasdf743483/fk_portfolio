package jp.co.cosmos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.cosmos.action.LoginAction;
import jp.co.cosmos.bean.ExamListBean;
import jp.co.cosmos.bean.InsertBean;
import jp.co.cosmos.bean.ListBean;
import jp.co.cosmos.common.ErrorConst;
import jp.co.cosmos.common.SettingConst;
import jp.co.cosmos.util.DBUtil;
import jp.co.cosmos.util.SafePassword;

public class ListDao extends DBUtil {

	static Log logger = LogFactory.getLog(LoginAction.class);
	public ListDao() {
		logger.info(SettingConst.LOG_NEW);
	}
	/**
	 * ���O�C���e�[�u���œo�^���s��
	 *
	 * @param insertBean
	 * @param name
	 * @return true:�o�^���� false:�o�^���s
	 * @throws SQLException
	 * @throws Exception
	 */
	public List<ListBean> allEmpInfo()
			throws SQLException, Exception {
		logger.info(SettingConst.LOG_START);
		// ��`
		PreparedStatement ps = null;
		ResultSet rs = null;
		Connection conn = null;
		StringBuffer sqlBuffer = new StringBuffer();
		List<ListBean> empInfoList = new ArrayList<ListBean>();

		try {
			conn = this.connectionDB();
			// SQL���̐���
			sqlBuffer.append("select ");
			sqlBuffer.append("emp_basic_info.emp_no ");
			sqlBuffer.append(",duty_cd ");
			sqlBuffer.append(",family_register ");
			sqlBuffer.append(",birth ");
			sqlBuffer.append(",first_name_kanji ");
			sqlBuffer.append(",last_name_kanji ");
			sqlBuffer.append(",tel_no ");
			sqlBuffer.append("from  ");
			sqlBuffer.append("emp_basic_info ");
			sqlBuffer.append(",emp_address_info ");
			sqlBuffer.append(",emp_duty_info ");
			sqlBuffer.append(",login ");
			sqlBuffer.append(",emp_examination_info ");
			sqlBuffer.append("where emp_basic_info.emp_no=emp_address_info.emp_no ");
			sqlBuffer.append("and emp_basic_info.emp_no=emp_duty_info.emp_no ");
			sqlBuffer.append("and emp_basic_info.del_flg='0' ");
			sqlBuffer.append("and emp_address_info.del_flg='0' ");
			sqlBuffer.append("and emp_duty_info.del_flg='0' ");
			sqlBuffer.append("and emp_examination_info.del_flg='0' ");
			sqlBuffer.append("and login.del_flg='0' ");
			sqlBuffer.append("group by emp_basic_info.emp_no ");


			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			// �v���y�A�[�h�X�e�[�g�����g�̍쐬
			ps = conn.prepareStatement(sqlBuffer.toString());

			// SQL���s
			rs = ps.executeQuery();

			if (logger.isDebugEnabled()) {
				logger.debug("�S���擾����");
			}
			// ���X�ƒl���擾
			while (rs.next()) {
				ListBean empInfoBean = new ListBean();
				empInfoBean.setUserId(rs.getString("duty_cd") + rs.getString("emp_no"));
				empInfoBean.setName(rs.getString("last_name_kanji") + rs.getString("first_name_kanji"));
				empInfoBean.setFamilyRegister(rs.getString("family_register"));
				empInfoBean.setBirth(rs.getString("birth"));
				empInfoBean.setTelNo(rs.getString("tel_no"));
				empInfoList.add(empInfoBean);
			}
			return empInfoList;

		} catch (SQLException e) {
			logger.error(ErrorConst.ERRORS_SQL);
			throw e;
		} catch (Exception e) {
			logger.error(ErrorConst.ERRORS_FATAL);
			throw e;
		} finally {

			 // DB�ؒf
			 this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);
		}

	}
}
