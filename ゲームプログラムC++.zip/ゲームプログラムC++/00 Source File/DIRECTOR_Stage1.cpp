#include "DIRECTOR.h"
#include <math.h>


//
//
//
void DIRECTOR::Stage1()
{
	//�L�[����
	
	if(GetKeyState('A') & 0x80)m_pHito->m_fYaw-=0.06;
	if(GetKeyState('D') & 0x80) m_pHito->m_fYaw+=0.06;
	if(GetKeyState('W') & 0x80) m_pHito->MoveForward(HITO_SPEED);
	if(GetKeyState('S') & 0x80) m_pHito->MoveBackward(HITO_SPEED);

	static int wait=0;//�o�����h�~
	//fk 2024.06.03 wait2 �ǉ�
	static int wait2 = 0;//�o�����h�~
	static int wait3 = 0;//�o�����h�~
	static int wait4 = 0;//�o�����h�~
	float pi = 3.14;
	if(wait<INT_MAX) wait++;
	if(GetKeyState(VK_SPACE) & 0x80 && wait>SHOT_WAIT && m_iNumShot<MAX_SHOT)
	{
		wait=0;
		m_Shot[m_iNumShot].vPos=m_pHito->m_vPos;
		m_Shot[m_iNumShot].vDir=m_pHito->m_vDir;
		m_iNumShot++;
		m_pSound->PlaySound(m_iFireSound[m_iFireSoundCounter],false);
		m_iFireSoundCounter++;
		if(m_iFireSoundCounter>=5) m_iFireSoundCounter=0;
		
	}

	/*
	* fk 2024.06.03 �ǉ� �J�n
	*/
	if (wait2 < INT_MAX) wait2++;
	if (GetKeyState(VK_SHIFT) & 0x80 && wait2 > SHOT_WAIT && m_iNumShot < MAX_SHOT)
	{
		wait2 = 0;
		m_Shot[m_iNumShot].vPos = m_pHito->m_vPos;
		m_Shot[m_iNumShot].vDir = m_pHito->m_vBackDir;
		m_iNumShot++;
		m_pSound->PlaySound(m_iFireSound[m_iFireSoundCounter], false);
		m_iFireSoundCounter++;
		if (m_iFireSoundCounter >= 5) m_iFireSoundCounter = 0;

	}

	/*
	* fk 2024.06.03 �ǉ� �I��
	*/

	/*
	* fk 2024.06.11 �ǉ� �J�n
	*/
	if (wait3 < INT_MAX) wait3++;
	if (GetKeyState(VK_INSERT) & 0x80 && wait3 > SHOT_WAIT && m_iNumShot < MAX_SHOT)
	{
		wait3 = 0;
		m_Shot30[m_iNumShot].vPos = m_pHito->m_vPos;
		m_Shot31[m_iNumShot].vPos = m_pHito->m_vPos;
		m_Shot32[m_iNumShot].vPos = m_pHito->m_vPos;
		m_Shot33[m_iNumShot].vPos = m_pHito->m_vPos;
		m_Shot30[m_iNumShot].vDir = m_pHito->m_vShot30Dir;
		m_Shot31[m_iNumShot].vDir = m_pHito->m_vShot31Dir;
		m_Shot32[m_iNumShot].vDir = m_pHito->m_vShot32Dir;
		m_Shot33[m_iNumShot].vDir = m_pHito->m_vShot33Dir;

		


		m_iNumShot++;
		m_pSound->PlaySound(m_iFireSound[m_iFireSoundCounter], false);
		m_iFireSoundCounter++;
		if (m_iFireSoundCounter >= 5) m_iFireSoundCounter = 0;

	}

	if (wait4 < INT_MAX) wait4++;
	if (GetKeyState(VK_LEFT) & 0x80 && wait4 > SHOT_WAIT && m_iNumShot < MAX_SHOT)
	{
		wait4 = 0;
		
		m_Shot40[m_iNumShot].vPos = m_pHito->m_vPos;
		m_Shot41[m_iNumShot].vPos = m_pHito->m_vPos;
		m_Shot42[m_iNumShot].vPos = m_pHito->m_vPos;
		m_Shot40[m_iNumShot].vDir = m_pHito->m_vShot40Dir;
		m_Shot41[m_iNumShot].vDir = m_pHito->m_vShot41Dir;
		m_Shot42[m_iNumShot].vDir = m_pHito->m_vShot42Dir;


		m_iNumShot++;
		m_pSound->PlaySound(m_iFireSound[m_iFireSoundCounter], false);
		m_iFireSoundCounter++;
		if (m_iFireSoundCounter >= 5) m_iFireSoundCounter = 0;

	}

	/*
	* fk 2024.06.11 �ǉ� �I��
	*/

	



	

	//�J��������l���h�ЂƁh�𒍎�����悤��
	float x=m_pHito->m_vPos.x,y=m_pHito->m_vPos.y,z=m_pHito->m_vPos.z;
	m_pCamera->SetCameraPositionGaze(x-7,y+7,z-7,x,y,z);

	//��l�������_�[
	D3DXVECTOR3 vLightDir(1,1,1);
	m_pFieldMesh->Render(m_pCamera->m_mView,m_pCamera->m_mProj,vLightDir,m_pCamera->m_vPos);
	m_pHito->Render(m_pCamera->m_mView,m_pCamera->m_mProj,vLightDir,m_pCamera->m_vPos);
	//�e�@�����_�[
	for(int i=0;i<m_iNumShot;i++)
	{
		
		m_Shot[i].vPos += m_Shot[i].vDir * 0.1;
		m_pShotMesh->m_vPos=m_Shot[i].vPos;
		m_pShotMesh->Render(m_pCamera->m_mView,m_pCamera->m_mProj,vLightDir,m_pCamera->m_vPos);
	}

	/*
	* fk 2024.06.11 �ǉ��J�n
	*/
	//�e�@�����_�[
	for (int i = 0; i < m_iNumShot; i++)
	{
		m_Shot30[i].vPos.x += m_Shot30[i].vDir.x * 0.1;
		m_Shot30[i].vPos.y += m_Shot30[i].vDir.y * 0.1;
		m_Shot30[i].vPos.z += m_Shot30[i].vDir.z * 0.1;
		m_pShotMesh->m_vPos = m_Shot30[i].vPos;
		m_pShotMesh->Render(m_pCamera->m_mView, m_pCamera->m_mProj, vLightDir, m_pCamera->m_vPos);
	}

	//�e�@�����_�[
	for (int i = 0; i < m_iNumShot; i++)
	{
		m_Shot31[i].vPos.x += m_Shot31[i].vDir.x * 0.1;
		m_Shot31[i].vPos.y += m_Shot31[i].vDir.y * 0.1;
		m_Shot31[i].vPos.z += m_Shot31[i].vDir.z * 0.1;
		m_pShotMesh->m_vPos = m_Shot31[i].vPos;
		m_pShotMesh->Render(m_pCamera->m_mView, m_pCamera->m_mProj, vLightDir, m_pCamera->m_vPos);
	}

	//�e�@�����_�[
	for (int i = 0; i < m_iNumShot; i++)
	{
		m_Shot32[i].vPos.x += m_Shot32[i].vDir.x * 0.1;
		m_Shot32[i].vPos.y += m_Shot32[i].vDir.y * 0.1;
		m_Shot32[i].vPos.z += m_Shot32[i].vDir.z * 0.1;
		m_pShotMesh->m_vPos = m_Shot32[i].vPos;
		m_pShotMesh->Render(m_pCamera->m_mView, m_pCamera->m_mProj, vLightDir, m_pCamera->m_vPos);
	}

	//�e�@�����_�[
	for (int i = 0; i < m_iNumShot; i++)
	{
		m_Shot33[i].vPos.x += m_Shot33[i].vDir.x * 0.1;
		m_Shot33[i].vPos.y += m_Shot33[i].vDir.y * 0.1;
		m_Shot33[i].vPos.z += m_Shot33[i].vDir.z * 0.1;
		m_pShotMesh->m_vPos = m_Shot33[i].vPos;
		m_pShotMesh->Render(m_pCamera->m_mView, m_pCamera->m_mProj, vLightDir, m_pCamera->m_vPos);
	}

	//�e�@�����_�[
	for (int i = 0; i < m_iNumShot; i++)
	{
		m_Shot40[i].vPos.x += m_Shot40[i].vDir.x * 0.1;
		m_Shot40[i].vPos.y += m_Shot40[i].vDir.y * 0.1;
		m_Shot40[i].vPos.z += m_Shot40[i].vDir.z * 0.1;
		m_pShotMesh->m_vPos = m_Shot40[i].vPos;
		m_pShotMesh->Render(m_pCamera->m_mView, m_pCamera->m_mProj, vLightDir, m_pCamera->m_vPos);
	}

	//�e�@�����_�[
	for (int i = 0; i < m_iNumShot; i++)
	{
		m_Shot41[i].vPos.x += m_Shot41[i].vDir.x * 0.1;
		m_Shot41[i].vPos.y += m_Shot41[i].vDir.y * 0.1;
		m_Shot41[i].vPos.z += m_Shot41[i].vDir.z * 0.1;
		m_pShotMesh->m_vPos = m_Shot41[i].vPos;
		m_pShotMesh->Render(m_pCamera->m_mView, m_pCamera->m_mProj, vLightDir, m_pCamera->m_vPos);
	}

	//�e�@�����_�[
	for (int i = 0; i < m_iNumShot; i++)
	{
		m_Shot42[i].vPos.x += m_Shot42[i].vDir.x * 0.1;
		m_Shot42[i].vPos.y += m_Shot42[i].vDir.y * 0.1;
		m_Shot42[i].vPos.z += m_Shot42[i].vDir.z * 0.1;
		m_pShotMesh->m_vPos = m_Shot42[i].vPos;
		m_pShotMesh->Render(m_pCamera->m_mView, m_pCamera->m_mProj, vLightDir, m_pCamera->m_vPos);
	}

	/*
	* fk 2024.06.11 �ǉ��I��
	*/

	
	//�����X�^�[�����_�[
	for(int i=0;i<m_iNumMonster;i++)
	{
		m_pMonster[i]->Render(m_pCamera->m_mView,m_pCamera->m_mProj,vLightDir,m_pCamera->m_vPos);
	}

	//�d��
	if(m_pHito->m_vPos.y>0.8+GRAV)
	{
		m_pHito->m_vPos.y-=GRAV;
	}
	for(int i=0;i<m_iNumMonster;i++)
	{
		if(m_pMonster[i]->m_vPos.y>0.4+GRAV)
		{
			m_pMonster[i]->m_vPos.y-=GRAV;
		}
	}
	//�����X�^�[����l����ǂ�
	for(int i=0;i<m_iNumMonster;i++)
	{
		m_pMonster[i]->m_iWait++;
		if(m_pMonster[i]->m_iWait>BAKA_TIME)
		{
			m_pMonster[i]->m_vTargetDir=m_pHito->m_vPos-m_pMonster[i]->m_vPos;
			D3DXVec3Normalize(&m_pMonster[i]->m_vTargetDir,&m_pMonster[i]->m_vTargetDir);
			m_pMonster[i]->m_iWait=(int)(((float)rand()/(float)RAND_MAX)*(float)BAKA_TIME);
		}
		m_pMonster[i]->m_vPos+=m_pMonster[i]->m_vTargetDir*MONSTER_SPEED;
	}
	//��l���ƃ����X�^�[�̓����蔻�� ���E������
	for(int i=0;i<m_iNumMonster;i++)
	{
		
		float fLen=D3DXVec3Length(&(m_pHito->m_vPos-m_pMonster[i]->m_vPos));
		if(fLen<1.0)//������
		{
			m_Scene=GAMEOVER;
			m_pSound->StopSound(m_iBGMSound);
			m_pSound->PlaySound(m_iGameOverSound,true);
		}
	}

	//�e�ƃ����X�^�[�̓����蔻�� ���E������
	for(int i=0;i<m_iNumShot;i++)
	{
		for(int k=0;k<m_iNumMonster;k++)
		{
			float fLen=D3DXVec3Length(&(m_Shot[i].vPos-m_pMonster[k]->m_vPos));
			float fLen30 = D3DXVec3Length(&(m_Shot30[i].vPos - m_pMonster[k]->m_vPos));
			float fLen31 = D3DXVec3Length(&(m_Shot31[i].vPos - m_pMonster[k]->m_vPos));
			float fLen32 = D3DXVec3Length(&(m_Shot32[i].vPos - m_pMonster[k]->m_vPos));
			float fLen33 = D3DXVec3Length(&(m_Shot33[i].vPos - m_pMonster[k]->m_vPos));
			float fLen40 = D3DXVec3Length(&(m_Shot40[i].vPos - m_pMonster[k]->m_vPos));
			float fLen41 = D3DXVec3Length(&(m_Shot41[i].vPos - m_pMonster[k]->m_vPos));
			float fLen42 = D3DXVec3Length(&(m_Shot42[i].vPos - m_pMonster[k]->m_vPos));
			if(fLen<0.8 
				|| fLen30<0.8
				|| fLen31<0.8
				|| fLen32<0.8
				|| fLen33<0.8
				|| fLen40<0.8
				|| fLen41<0.8
				|| fLen42<0.8)//������
			{
				m_iNumMonster--;
				memcpy(m_pMonster[k],m_pMonster[m_iNumMonster],sizeof(CHARACTER));
				m_iNumShot--;
				memcpy(&m_Shot[i],&m_Shot[m_iNumShot],sizeof(SHOT_DATA));
				m_pSound->PlaySound(m_iHitSound,false);
			}
		}
	}
	//�e�̏���
	for(int i=0;i<m_iNumShot;i++)
	{
		float fLen=D3DXVec3Length(&(m_pHito->m_vPos-m_Shot[i].vPos));
		if(fLen>50)
		{
			m_iNumShot--;
			memcpy(&m_Shot[i],&m_Shot[m_iNumShot],sizeof(SHOT_DATA));
		}
	}

	//WIN
	if(m_iNumMonster<=0)
	{
		m_Scene=WIN;
	}
	//���\��
	char info[256];
	sprintf(info,"�����X�^�[�̐� %d",m_iNumMonster);
	m_pD3d->RenderText(info,10,10);
}