package jp.co.cosmos.util;

import java.util.ArrayList;
import java.util.List;

import jp.co.cosmos.bean.EraBean;
import jp.co.cosmos.bean.TodoufukenBean;
import jp.co.cosmos.common.StrConst;

public class ListUtil {
	/**
	 * �N���̃��X�g�쐬
	 */
	public static List<EraBean> getEraList() {
		// ��`
		List<EraBean> eraList = new ArrayList<EraBean>();
		EraBean eraHeisei = new EraBean();
		EraBean eraShowa = new EraBean();

		// �l���Z�b�g
		eraHeisei.setEraValue(StrConst.HEISEI);
		eraHeisei.setEraName(StrConst.HEISEI);
		eraShowa.setEraName(StrConst.SHOUWA);
		eraShowa.setEraValue(StrConst.SHOUWA);
		eraList.add(eraHeisei);
		eraList.add(eraShowa);

		// �Ԃ�
		return eraList;
	}

	/**
	 * �s���{���̃��X�g�쐬
	 */
	public static List<TodoufukenBean> getTodoufukenList() {
		// ��`
		List<TodoufukenBean> todoufukenList = new ArrayList<TodoufukenBean>();

		// �l���Z�b�g
		for (int i = 0; i < StrConst.TODOUFUKEN.length; i++) {
			TodoufukenBean todoufukenBean = new TodoufukenBean();
			todoufukenBean.setTodoufukenName(StrConst.TODOUFUKEN[i]);
			todoufukenBean.setTodoufukenValue(StrConst.TODOUFUKEN[i]);
			todoufukenList.add(todoufukenBean);
		}

		// �Ԃ�
		return todoufukenList;
	}
}
