package jp.co.cosmos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import jp.co.cosmos.util.DBUtil;
import jp.co.cosmos.bean.ExamListBean;
import jp.co.cosmos.bean.DutyListBean;
import jp.co.cosmos.common.ErrorConst;
import jp.co.cosmos.common.SettingConst;

/**
 * ���Ǝ������ƐE�����i��������Ă��� �쐬�� 2014/5/27
 *
 * @author �����\�C
 *
 */
public class ShowInsertDao extends DBUtil {

	static Log logger = LogFactory.getLog(ShowInsertDao.class);
	public ShowInsertDao() {
		logger.info(SettingConst.LOG_NEW);
	}

	/**
	 *DB���獑�Ǝ�����������Ă���
	 *
	 * @param userId
	 * @return
	 **/
	public List<ExamListBean> selectExaminationNm() throws SQLException,
			Exception {
		logger.info(SettingConst.LOG_START);
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();

		List<ExamListBean> arrayList = new ArrayList<ExamListBean>();

		try {
			conn = this.connectionDB();
			// SQL���̐���
			sqlBuffer.append("select ");
			sqlBuffer.append("examination_nm ");
			sqlBuffer.append(",examination_cd ");
			sqlBuffer.append("from ");
			sqlBuffer.append("examination ");
			sqlBuffer.append("order by sort_key asc  ");

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			ps = conn.prepareStatement(sqlBuffer.toString());

			// SQL���s
			rs = ps.executeQuery();

			if (logger.isDebugEnabled()) {
				logger.debug("SQL���s����");
			}

			// ���X�ƒl���擾
			while (rs.next()) {
				ExamListBean menuBean = new ExamListBean();
				menuBean.setExaminationNm(rs.getString("examination_nm"));
				menuBean.setExaminationCd(rs.getString("examination_cd"));
				arrayList.add(menuBean);

			}
			return arrayList;
		} catch (SQLException e) {

			throw e;
		} catch (Exception e) {

			throw e;
		} finally {
			// DB�ؒf
			this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);

		}

	}

	/**
	 *DB����E�����i��������Ă���
	 *
	 * @param userId
	 * @return
	 **/
	public List<DutyListBean> selectDutyNm() throws SQLException, Exception {
		logger.info(SettingConst.LOG_START);
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		StringBuffer sqlBuffer = new StringBuffer();

		List<DutyListBean> arrayList = new ArrayList<DutyListBean>();
		try {
			conn = this.connectionDB();
			// SQL���̐���
			sqlBuffer.append("select ");
			sqlBuffer.append("duty_nm ");
			sqlBuffer.append(",duty_cd ");
			sqlBuffer.append("from ");
			sqlBuffer.append("duty ");
			sqlBuffer.append("order by ");
			sqlBuffer.append("duty_cd asc ");

			if (logger.isDebugEnabled()) {
				logger.debug(sqlBuffer.toString());
			}

			ps = conn.prepareStatement(sqlBuffer.toString());

			// SQL���s
			rs = ps.executeQuery();

			if (logger.isDebugEnabled()) {
				logger.debug("SQL���s����");
			}
			// ���X�ƒl���擾
			while (rs.next()) {
				DutyListBean menuBean = new DutyListBean();
				menuBean.setDutyNm(rs.getString("duty_nm"));
				menuBean.setDutyCd(rs.getString("duty_cd"));
				arrayList.add(menuBean);
			}
			return arrayList;
		} catch (SQLException e) {

			logger.error(ErrorConst.ERRORS_SQL, e);
			throw e;
		} catch (Exception e) {

			logger.fatal(ErrorConst.ERRORS_FATAL, e);
			throw e;
		} finally {
			// DB�ؒf
			this.close(conn);
			this.close(ps);
			this.close(rs);
			logger.info(SettingConst.LOG_END);

		}


	}
}
