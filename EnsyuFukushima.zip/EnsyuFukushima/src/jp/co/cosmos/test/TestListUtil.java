package jp.co.cosmos.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;

import org.junit.*;

import jp.co.cosmos.bean.EraBean;
import jp.co.cosmos.bean.TodoufukenBean;
import jp.co.cosmos.util.ListUtil;

public class TestListUtil {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void getEraList_���ڈ�v() {
		List<EraBean> eraList = ListUtil.getEraList();
		assertEquals("H", eraList.get(0).getEraName());
		assertEquals("H", eraList.get(0).getEraValue());
		assertEquals("S", eraList.get(1).getEraName());
		assertEquals("S", eraList.get(1).getEraValue());
	}

	@Test
	public void getTodoufukenList_���ڈ�v() {
		List<TodoufukenBean> todoufukenList = ListUtil.getTodoufukenList();

		assertEquals("�k�C��", todoufukenList.get(0).getTodoufukenName());

		assertEquals("�k�C��", todoufukenList.get(0).getTodoufukenValue());

		assertEquals("�X��", todoufukenList.get(1).getTodoufukenName());

		assertEquals("�X��", todoufukenList.get(1).getTodoufukenValue());

		assertEquals("��茧", todoufukenList.get(2).getTodoufukenName());

		assertEquals("��茧", todoufukenList.get(2).getTodoufukenValue());

		assertEquals("�{�錧", todoufukenList.get(3).getTodoufukenName());

		assertEquals("�{�錧", todoufukenList.get(3).getTodoufukenValue());

		assertEquals("�H�c��", todoufukenList.get(4).getTodoufukenName());

		assertEquals("�H�c��", todoufukenList.get(4).getTodoufukenValue());

		assertEquals("�R�`��", todoufukenList.get(5).getTodoufukenName());

		assertEquals("�R�`��", todoufukenList.get(5).getTodoufukenValue());

		assertEquals("������", todoufukenList.get(6).getTodoufukenName());

		assertEquals("������", todoufukenList.get(6).getTodoufukenValue());

		assertEquals("��錧", todoufukenList.get(7).getTodoufukenName());

		assertEquals("��錧", todoufukenList.get(7).getTodoufukenValue());

		assertEquals("�Ȗ،�", todoufukenList.get(8).getTodoufukenName());

		assertEquals("�Ȗ،�", todoufukenList.get(8).getTodoufukenValue());

		assertEquals("�Q�n��", todoufukenList.get(9).getTodoufukenName());

		assertEquals("�Q�n��", todoufukenList.get(9).getTodoufukenValue());

		assertEquals("��ʌ�", todoufukenList.get(10).getTodoufukenName());

		assertEquals("��ʌ�", todoufukenList.get(10).getTodoufukenValue());

		assertEquals("��t��", todoufukenList.get(11).getTodoufukenName());

		assertEquals("��t��", todoufukenList.get(11).getTodoufukenValue());

		assertEquals("�����s", todoufukenList.get(12).getTodoufukenName());

		assertEquals("�����s", todoufukenList.get(12).getTodoufukenValue());

		assertEquals("�_�ސ쌧", todoufukenList.get(13).getTodoufukenName());

		assertEquals("�_�ސ쌧", todoufukenList.get(13).getTodoufukenValue());

		assertEquals("�V����", todoufukenList.get(14).getTodoufukenName());

		assertEquals("�V����", todoufukenList.get(14).getTodoufukenValue());

		assertEquals("�x�R��", todoufukenList.get(15).getTodoufukenName());

		assertEquals("�x�R��", todoufukenList.get(15).getTodoufukenValue());

		assertEquals("�ΐ쌧", todoufukenList.get(16).getTodoufukenName());

		assertEquals("�ΐ쌧", todoufukenList.get(16).getTodoufukenValue());

		assertEquals("���䌧", todoufukenList.get(17).getTodoufukenName());

		assertEquals("���䌧", todoufukenList.get(17).getTodoufukenValue());

		assertEquals("�R����", todoufukenList.get(18).getTodoufukenName());

		assertEquals("�R����", todoufukenList.get(18).getTodoufukenValue());

		assertEquals("���쌧", todoufukenList.get(19).getTodoufukenName());

		assertEquals("���쌧", todoufukenList.get(19).getTodoufukenValue());

		assertEquals("�򕌌�", todoufukenList.get(20).getTodoufukenName());

		assertEquals("�򕌌�", todoufukenList.get(20).getTodoufukenValue());

		assertEquals("�É���", todoufukenList.get(21).getTodoufukenName());

		assertEquals("�É���", todoufukenList.get(21).getTodoufukenValue());

		assertEquals("���m��", todoufukenList.get(22).getTodoufukenName());

		assertEquals("���m��", todoufukenList.get(22).getTodoufukenValue());

		assertEquals("�O�d��", todoufukenList.get(23).getTodoufukenName());

		assertEquals("�O�d��", todoufukenList.get(23).getTodoufukenValue());

		assertEquals("���ꌧ", todoufukenList.get(24).getTodoufukenName());

		assertEquals("���ꌧ", todoufukenList.get(24).getTodoufukenValue());

		assertEquals("���s�{", todoufukenList.get(25).getTodoufukenName());

		assertEquals("���s�{", todoufukenList.get(25).getTodoufukenValue());

		assertEquals("���{", todoufukenList.get(26).getTodoufukenName());

		assertEquals("���{", todoufukenList.get(26).getTodoufukenValue());

		assertEquals("���Ɍ�", todoufukenList.get(27).getTodoufukenName());

		assertEquals("���Ɍ�", todoufukenList.get(27).getTodoufukenValue());

		assertEquals("�ޗǌ�", todoufukenList.get(28).getTodoufukenName());

		assertEquals("�ޗǌ�", todoufukenList.get(28).getTodoufukenValue());

		assertEquals("�a�̎R��", todoufukenList.get(29).getTodoufukenName());

		assertEquals("�a�̎R��", todoufukenList.get(29).getTodoufukenValue());

		assertEquals("���挧", todoufukenList.get(30).getTodoufukenName());

		assertEquals("���挧", todoufukenList.get(30).getTodoufukenValue());

		assertEquals("������", todoufukenList.get(31).getTodoufukenName());

		assertEquals("������", todoufukenList.get(31).getTodoufukenValue());

		assertEquals("���R��", todoufukenList.get(32).getTodoufukenName());

		assertEquals("���R��", todoufukenList.get(32).getTodoufukenValue());

		assertEquals("�L����", todoufukenList.get(33).getTodoufukenName());

		assertEquals("�L����", todoufukenList.get(33).getTodoufukenValue());

		assertEquals("�R����", todoufukenList.get(34).getTodoufukenName());

		assertEquals("�R����", todoufukenList.get(34).getTodoufukenValue());

		assertEquals("������", todoufukenList.get(35).getTodoufukenName());

		assertEquals("������", todoufukenList.get(35).getTodoufukenValue());

		assertEquals("���쌧", todoufukenList.get(36).getTodoufukenName());

		assertEquals("���쌧", todoufukenList.get(36).getTodoufukenValue());

		assertEquals("���Q��", todoufukenList.get(37).getTodoufukenName());

		assertEquals("���Q��", todoufukenList.get(37).getTodoufukenValue());

		assertEquals("���m��", todoufukenList.get(38).getTodoufukenName());

		assertEquals("���m��", todoufukenList.get(38).getTodoufukenValue());

		assertEquals("������", todoufukenList.get(39).getTodoufukenName());

		assertEquals("������", todoufukenList.get(39).getTodoufukenValue());

		assertEquals("���ꌧ", todoufukenList.get(40).getTodoufukenName());

		assertEquals("���ꌧ", todoufukenList.get(40).getTodoufukenValue());

		assertEquals("���茧", todoufukenList.get(41).getTodoufukenName());

		assertEquals("���茧", todoufukenList.get(41).getTodoufukenValue());

		assertEquals("�F�{��", todoufukenList.get(42).getTodoufukenName());

		assertEquals("�F�{��", todoufukenList.get(42).getTodoufukenValue());

		assertEquals("�啪��", todoufukenList.get(43).getTodoufukenName());

		assertEquals("�啪��", todoufukenList.get(43).getTodoufukenValue());

		assertEquals("�{�茧", todoufukenList.get(44).getTodoufukenName());

		assertEquals("�{�茧", todoufukenList.get(44).getTodoufukenValue());

		assertEquals("��������", todoufukenList.get(45).getTodoufukenName());

		assertEquals("��������", todoufukenList.get(45).getTodoufukenValue());

		assertEquals("���ꌧ", todoufukenList.get(46).getTodoufukenName());

		assertEquals("���ꌧ", todoufukenList.get(46).getTodoufukenValue());
	}
}

