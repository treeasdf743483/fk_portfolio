package jp.co.cosmos.action;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.cosmos.bean.DutyListBean;
import jp.co.cosmos.bean.ExamListBean;
import jp.co.cosmos.bean.LoginBean;
import jp.co.cosmos.common.ErrorConst;
import jp.co.cosmos.common.SettingConst;

import jp.co.cosmos.dao.ShowInsertDao;
import jp.co.cosmos.util.ListUtil;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class ShowInsertAction extends Action {

	static Log logger = LogFactory.getLog(LoginAction.class);

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		logger.info(SettingConst.LOG_START);
		// ��`
		List<ExamListBean> examinationNmList = new ArrayList<ExamListBean>();
		List<DutyListBean> dutyNmList = new ArrayList<DutyListBean>();


		try {
			// select���ď����擾�B
			ShowInsertDao insertShowDao = new ShowInsertDao();
			examinationNmList = insertShowDao.selectExaminationNm();
			dutyNmList = insertShowDao.selectDutyNm();

			// jsp���ɃZ�b�g����
			HttpSession session = ((HttpServletRequest) request).getSession();
			LoginBean loginBean = new LoginBean();
			System.out.println(loginBean.getName());
			session.setAttribute("examinationNmList", examinationNmList);
			session.setAttribute("dutyNmList", dutyNmList);
			session.setAttribute("todoufukenList", ListUtil.getTodoufukenList());
			session.setAttribute("eraList", ListUtil.getEraList());


			// �J��
			return mapping.findForward("success");
			// �J��
		} catch (SQLException e) {

			logger.error(ErrorConst.ERRORS_SQL, e);
			request.setAttribute("systemError", e);
			request.setAttribute("errorDetail",e.getStackTrace());
			return mapping.findForward("error");
		} catch (Exception e) {

			logger.fatal(ErrorConst.ERRORS_FATAL, e);
			request.setAttribute("systemError", e);
			request.setAttribute("errorDetail",e.getStackTrace());
			return mapping.findForward("error");
		} finally {
			logger.info(SettingConst.LOG_END);
		}

	}
}
