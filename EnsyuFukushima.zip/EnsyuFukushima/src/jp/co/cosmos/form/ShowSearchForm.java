package jp.co.cosmos.form;

public class ShowSearchForm {
	
}
