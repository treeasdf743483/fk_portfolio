package jp.co.cosmos.action;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jp.co.cosmos.form.LoginForm;

import jp.co.cosmos.common.ResourseKeyConst;

import jp.co.cosmos.dao.LoginDao;
import jp.co.cosmos.bean.LoginBean;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import jp.co.cosmos.common.SettingConst;

/**
 * �K�؂�userId�ƃp�X���[�h�̏ꍇ�Ƀ��O�C������Action author �����\�C
 * �쐬��:2014/05/15 9:54
 */
public class LoginAction extends Action {

	static Log logger = LogFactory.getLog(LoginAction.class);

	/**
	 * ���O�C����ʂ��烁�j���[��ʂ֑J�ڂ���
	 *
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return ActionMapping
	 * @throws Exception
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		// ��`
		LoginForm loginForm = (LoginForm) form;
		LoginDao selectDao = new LoginDao();
		String userId = loginForm.getUserId();
		String password = loginForm.getPassword();
		LoginBean loginBean = new LoginBean();
		ActionErrors errors = new ActionErrors();
		logger.info(SettingConst.LOG_START);
		HttpSession session = request.getSession();
		session.setAttribute("loginBean", loginBean);

		// userId�ƃp�X���[�h����v����ꍇ
		try {

			if (selectDao.isMatchLoginInfo(userId, password)) {
				loginBean = selectDao.loginInfo(userId);
				if(Integer.parseInt(loginBean.getDutyCd()) >= 4 &&  Integer.parseInt(loginBean.getDutyCd()) != 9){
				loginBean.setAuthFlg("1");
			}
				session.setAttribute("loginBean", loginBean);

				logger.info("���O�C������");
				logger.info(SettingConst.LOG_END);
				return mapping.findForward("success");

			} else {

				errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage(
						ResourseKeyConst.LOGIN_ERROR));
				saveErrors(request,errors);
				logger.info("���O�C�����s");
				logger.info(SettingConst.LOG_END);
				return mapping.getInputForward();
			}
		} catch (SQLException e) {

			logger.error("SQL�G���[", e);
			request.setAttribute("systemError", e);

			
			request.setAttribute("errorDetail",e.getStackTrace());

			return mapping.findForward("error");
		} catch (Exception e) {

			logger.fatal("�v���I�ȃG���[", e);

			request.setAttribute("systemError", e);
			request.setAttribute("errorDetail",e.getStackTrace());

			return mapping.findForward("error");
		}
	}

}
