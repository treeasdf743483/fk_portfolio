package jp.co.cosmos.form;

import org.apache.struts.action.ActionForm;

public class BackMenuForm extends ActionForm{

}
