function out(){
	if(confirm("ログアウトしますか？")){
		location.href = "/EnsyuFukushima/pages/login.jsp";
	}

}